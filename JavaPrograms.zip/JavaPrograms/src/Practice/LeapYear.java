package Practice;

public class LeapYear {

}
