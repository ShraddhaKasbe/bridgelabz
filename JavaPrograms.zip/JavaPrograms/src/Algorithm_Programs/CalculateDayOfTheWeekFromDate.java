package Algorithm_Programs;

import java.util.Scanner;

public class CalculateDayOfTheWeekFromDate 
{
	public static void main(String[] args)
	{
		Utility utility=new Utility();
		Utility.dayOfWeek();
		
	}

}
