package Algorithm_Programs;

import java.util.Scanner;

public class MinimizeTaskDeadline
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of tasks to be completed:");
		int numOftasks=sc.nextInt();
		System.out.println("Enter Time required to complete the task:");
		int minutes=sc.nextInt();
		System.out.println("Enter the deadline for the task:");
		int deadline=sc.nextInt();
		
	}

}
