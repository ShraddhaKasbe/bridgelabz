package Algorithm_Programs;

import java.io.IOException;

public class BinarySearchWords 
{
	public static void main(String[] args) throws IOException
	{
		Utility utility=new Utility();
		Utility.BinarySearchForWords();
		
	}

}
