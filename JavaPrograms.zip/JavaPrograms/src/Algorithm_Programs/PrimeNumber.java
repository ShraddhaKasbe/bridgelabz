package Algorithm_Programs;

public class PrimeNumber
{
	public static void main(String[] args)
	{
		Utility ut=new Utility();
		System.out.println("Prime Numbers between 1-1000 are:");
		ut.primeNumber();
		
	}

}
