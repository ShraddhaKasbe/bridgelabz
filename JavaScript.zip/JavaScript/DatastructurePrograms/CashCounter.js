/*/**********************************************************************************
 *  Purpose         : Simulate Banking Cash Counter
 *  @file           : CashCounter.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var cashcount=require('./Queue.js');//requires Queue.js file to perform queue operations
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,  //input stream
    output:process.stdout //output stream
});
/*
    @param accepting the balance 
    @param accept no of people in a queue
    @param accepts option from the user to peform operation
    @param accepts amount to be deposited
    @param accepts amount to be withdrawn
*/
var Balance=rl.question("Enter the balance:",MaintainBalance)
function MaintainBalance(Balance)
{
    var no_of_people=rl.question("Enter the number of people in a queue: ",cashcounter);
    function cashcounter(no_of_people)
    {
        
        let queue=new cashcount.Queue();//creating and accessing queue operations
        for(var i=0;i<no_of_people;i++)
        {
            queue.enqueue(i);//enqueue operation to push no of people in a
        }
        options();// option function to display list of options to perform operations

        function options()
        {
            console.log(); 
            console.log("Press 1 for Depositing Money  ");//for depositing
            console.log("Press 2 for withdrawing Money ");//for withdrawing
            console.log("Press 3 to check length of the queue ");//to check queue length
            console.log("Press 4 to check balance ");//to check balance
            console.log(); 
                
            var choice=rl.question("Enter your Choice: ",transactions);
            function transactions(choice)
            {
                switch(choice)
                {
                    case '1'://case 1 for depositing money
                    var deposit_amount=rl.question("Enter the amount to be deposited: ",deposit)        
                    function deposit(deposit_amount)
                    {
                        Balance=parseInt(parseInt(Balance) + parseInt(deposit_amount));//adds actual balance with deposited amount
                        console.log("Balance after depositing money: "+Balance);//displays total amount after deposit operation
                        queue.dequeue();//dequeue operation to remove people from the queue after performing deposit operation
                        no_of_people--; //decrement queue size 
                        if(no_of_people==0)
                            {
                                console.log("Queue is empty");//prints when queue is empty
                                return;
                            }
                        options();  //option function to display list of options to perform operations
                    } break;


                    case '2'://case 2 for withdrawing money
                    var withdraw_amount=rl.question("Enter the amount to be withdrawn: ",withdraw);
                    function withdraw(withdraw_amount)
                    {              
                        if(parseInt(Balance)<parseInt(withdraw_amount))//checks if amount to be withdrawn is > balance
                        {
                            console.log("Withdraw amount is greater than available balance");//prints if withdraw amount > balance amount
                        }
                        else
                        {
                            Balance=parseInt(parseInt(Balance)-parseInt(withdraw_amount));//substracts actual balance with withdrawn amount
                            console.log("Balance after withdrawing money: "+Balance);//displays total amount after withdraw operation
                            queue.dequeue();//dequeue operation to remove people from the queue after performing withdraw operation
                            no_of_people--;
                            if(no_of_people==0)
                            {
                                console.log("Queue is empty");//prints when queue is empty
                                return;
                            }
                            console.log();      
                            options();   //option function to display list of options to perform operations                       
                        }
                    }break;


                    case '3'://case 3 for displaying length of queue
                        console.log("Length of the queue is: "+queue.size);
                        options();  //option function to display list of options to perform operations 
                    
                    
                    break;

                    case '4':
                    console.log("Balance is: "+Balance);//displays the curent total balance
                    options();  //option function to display list of options to perform operations 

                    default :
                        if(choice>4)
                        console.log("Invalid Option");//prints if input option is >4
                        break;
                }
            }
        }
    }
    
}
       



                


        
        
    

