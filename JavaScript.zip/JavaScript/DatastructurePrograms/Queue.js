class Queue
{
    constructor()
    {
        this.items=[];
        this.size=0;
    }
    isEmpty() 
    { 
    return this.items.length == 0; 
    } 
    enqueue(elements)
    {
        this.items.push(elements);
        this.size++;
        
    }
    dequeue() 
    { 
        if(this.isEmpty()) 
        return "Underflow"; 
        else
        {this.size--;
        return this.items.shift(); 
        }
        
        
    } 
    printQueue() 
{ 
    var str = ""; 
    for(var i = 0; i < this.items.length; i++) 
        str += this.items[i] +" "; 
    return str; 
} 
}

module.exports={
    Queue
}