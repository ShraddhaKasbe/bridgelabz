class SNode
{
    constructor(data)
    {
        this.data=data;
        this.next=null;
    }
}

class StackLinkedList
{
    constructor()
    {
        this.top=null;
    }

    push(data)
    {
        var node=new SNode(data);
        if(this.top==null)
        {
            node.next=null;
        }
        else
        {
            node.next=this.top;
        }
        this.top=node;
    }

    display()
    {
        var current = this.top;  
        while (current.next!=null) 
        { 
            console.log(current.data);
            current=current.next;
        } 
        console.log(current.data); 
    }
}

var s=new StackLinkedList();

module.exports={
    StackLinkedList
}