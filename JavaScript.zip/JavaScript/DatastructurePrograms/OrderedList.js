/*/**********************************************************************************
 *  Purpose         : Simulate Banking Cash Counter
 *  @file           : OrderedList.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});


const fs = require('fs');
/*
    Reading the textfile 
*/
let txtFile = "../../Numbers.txt";
let str1 = fs.readFileSync(txtFile,'utf8');
let str=str1.slice(0,str1.length-1);
console.log(str);

var data=str.split(' ');//storing file data in array
console.log(data);

/*
    Creating a node class 
*/
class Node
{
    constructor(data)
    {
        this.data=data;
        this.next=null;
    }
}

class LinkedList
{   
    constructor()
    {
        this.size=0;
        this.head=null
    }
    
    insert(data)
    {  
        var node=new Node(data);
        if(this.head==null || node.data<this.head.data)
        {
            node.next=this.head;
            this.head=node;
        }    
       else
       {
           var temp=this.head;
           while(temp.next!=null && parseInt(node.data)>parseInt(temp.next.data))
            {
                temp=temp.next;
               
            }
            console.log(temp.data);
            node.next=temp.next;
            temp.next=node;
        }
    }
    remove(data)
    {
        var current=this.head;
        var prev=null;
        while(current!=null)//traverses till current points to null
        {
            if(current.data==data)//checks whether element to be deleted matches with the element in list
            {
                if(prev==null)
                {
                    this.head=current.next;
                }
                else
                {
                    prev.next=current.next;
                }
                this.size--; //decrements the size of the list after deleting the elements
            return current.element; 
        } 
        prev = current; 
        current = current.next; 
    } 
    this.insert(data); 
} 

    display()
    {
        var current = this.head; 
        var strlist=""; 
        while (current) 
        { 
           strlist+=current.data +" ";
            current=current.next;
        } 
        console.log(strlist); 

        var fs = require('fs');

        fs.writeFile('../../Numbers.txt',strlist, function (err) 
        {
            if (err) throw err;
            
        });
    }
}

var list=new LinkedList();
console.log("Linked List after adding numbers of file:");
for(var i=0;i<data.length;i++)
{
    list.insert(data[i]);
}
list.display();

var searchelement=rl.question("Enter an element to search:",Search);
function Search(searchelement)
{
    list.remove(searchelement);
    list.display();    

}
module.exports={
    LinkedList
}