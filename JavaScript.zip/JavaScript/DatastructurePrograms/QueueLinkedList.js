class QNode
{
    constructor(data)
    {
        this.data=data;
        this.next=null;
    }
}

class Queue
{
    constructor()
    {
        this.front=null;
        this.rear=null;
    }
    enqueue(data)
    {
        var node=new QNode(data);
        if(this.rear==null)
        {
            this.front=this.rear=node;
            return;
        }
        this.rear.next=node;
        this.rear=node;
    }
    display()
    {
        var current = this.front;  
        while (current.next!=null) 
        { 
            console.log(current.data);
            current=current.next;
        } 
        console.log(current.data); 
    }
}

var q=new Queue(); 


module.exports={
    Queue
}