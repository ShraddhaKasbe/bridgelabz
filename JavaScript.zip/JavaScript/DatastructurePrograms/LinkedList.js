
class Node
{
    constructor(data)
    {
        this.data=data;
        this.next=null;
    }
}

class LinkedList
{
    constructor()
    {
        this.size=0;
        this.head=null;
    }

    add(data)
    {
        var node=new Node(data);
        var current;
        if(this.head==null)
        {
            this.head=node;
        }
        else
        {
            current=this.head;
            while(current.next)
            {
                current=current.next;
            }
            current.next=node;
        }
        this.size++;
    }
    delete(data)
    {
       
        var current=this.head;
        var prev=null;
        while(current!=null)
        {
            if(current.data==data)
            {
                if(prev==null)
                {
                    this.head=current.next;
                }
                else
                {
                    prev.next=current.next;
                }
                this.size--; 
            return current.element; 
            } 
        prev = current; 
        current = current.next; 
        } 
    }

    remove(data)
    {
        var current=this.head;
        var prev=null;
        while(current!=null)
        {
            if(current.data==data)
            {
                if(prev==null)
                {
                    this.head=current.next;
                }
                else
                {
                    prev.next=current.next;
                }
                this.size--; 
            return current.element; 
        } 
        prev = current; 
        current = current.next; 
    } 
    this.add(data);
} 

addAtEnd(data)
{
    var node=new Node(data);
    var current;
    if(this.head==null)
    {
        this.head=node;
    }
    else
    {
        current=this.head;
        while(current.next)
        {
            current=current.next;
        }
        current.next=node;
    }
    this.size++;
}
addAtStart(data)
{
    var n=new Node(data);
    n.next=this.head;
    this.head=n;
}
    display()
    {
        var current = this.head;  
        while (current.next!=null) 
        { 
            console.log(current.data);
            current=current.next;
        } 
        console.log(current.data); 
    }

}
var list=new LinkedList();

module.exports={
LinkedList
}