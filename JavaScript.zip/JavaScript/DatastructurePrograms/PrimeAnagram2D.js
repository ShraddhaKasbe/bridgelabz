/*/**********************************************************************************
 *  Purpose         : store prime anagram number in 2D Array
 *  @file           : PrimeAnagram2D.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/


var prime=[];
var prime2=[];
for(var i=0;i<1000;i++)
{
    for(var j=i+1;j<1000;j++)
    {
        if(i%2!=0)//checks whether number is prime or not
        {
            var num=i.toString();//converts array into string using toString()
            var num2=j.toString();//converts array into string using toString()
            var n=num.split('').sort().join('').trim();
            var n1=num2.split('').sort().join('').trim();
            
            if(n==n1)//checks prime numbers whether they are anagram 
            {
                prime.push(i);//adds value i in the array prime
                prime.push(j);//adds value j in the array prime2            
                break;
            }
        }
    }
}

var primearr=prime.concat(prime2);//concat() used to join to arrays

/*filter method used to remove duplicate values*/
primearr = primearr.filter( function( item, index, inputArray )
{
    return inputArray.indexOf(item) == index;
});

/*Buuble Sort logic to sort the array*/
for(var i=0;i<primearr.length;i++)
{
    for(var j=0;j<primearr.length;j++)
    {
        if(primearr[j]>primearr[j+1])//checks whether first number > second number
        {
            var temp=primearr[j];//swaps the greatest number with smallest one using temp variable
            primearr[j]=primearr[j+1];
            primearr[j+1]=temp;
        }
    }
}

var arr=[];
console.log("Prime Numbers in 2D Array");
while(primearr.length>0)
{
    arr.push(primearr.splice(0,40));//splice() method used to store 1D Array in 2Dss
    console.log();
}

console.log(arr);//prints the 2D array with anagram numbers 

 

