/***********************************************************************************
 *  Purpose         : Simulate Banking Cash Counter
 *  @file           : UnorderedList.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});


const fs = require('fs');
/*
    Reading the textfile 
*/
let txtFile = "../../Names.txt";
let str1 = fs.readFileSync(txtFile,'utf8');
let str=str1.slice(0,str1.length-1);
console.log(str);

var data=str.split(' ');//storing file data in array
console.log(data);

/*
    Creating a node class 
*/
class Node
{
    constructor(data)
    {
        this.data=data;//stores value
        this.next=null;//points to other node
    }
}
/*
    Creating Linkedlist class 
*/
class LinkedList
{
    constructor()
    {
        this.size=0;//retrives the number of nodes in a list
        this.head=null;// assigns a node as head node of the list
    }

    /*
        Adding elements in list
    */
    add(data) 
    {
        var node=new Node(data);//creates a node with data to be inserted
        var current;// taking another pointer for traversing the list
        if(this.head==null) //checks whether list is empty
        {
            this.head=node;//if true then adds first node in a list and makes it head node
        }
        else
        {
            current=this.head;//initially current points to head
            while(current.next!=null)//traversing the list
            {
                current=current.next;
            }
            current.next=node;
        }
        this.size++;//incrementing size of list after adding element
    }

    /*
        Deleting elements from list
    */
    remove(data)
    {
        var current=this.head;
        var prev=null;
        while(current!=null)//traverses till current points to null
        {
            if(current.data==data)//checks whether element to be deleted matches with the element in list
            {
                if(prev==null)
                {
                    this.head=current.next;
                }
                else
                {
                    prev.next=current.next;
                }
                this.size--; //decrements the size of the list after deleting the elements
            return current.element; 
        } 
        prev = current; 
        current = current.next; 
    } 
    this.add(data); 
} 


    display()
    {
        var current = this.head; 
        var strlist=""; 
        while (current) 
        { 
           strlist+=current.data +" ";
            current=current.next;
        } 
        console.log(strlist); 

        var fs = require('fs');

        fs.writeFile('../../Names.txt',strlist, function (err) 
        {
            if (err) throw err;
            
        });
    }

}
var list=new LinkedList();
console.log("Linked List after adding words of file:");
for(var i=0;i<data.length;i++)
{
    list.add(data[i]);
}
list.display();

var searchelement=rl.question("Enter an element to search:",Search);
function Search(searchelement)
{
    list.remove(searchelement);
    list.display();    

}