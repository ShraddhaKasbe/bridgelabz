var primeAngaram=require('./StackLinkedList');

let dq=new primeAngaram.StackLinkedList();

for(var i=0;i<1000;i++)
{
    for(var j=i+1;j<1000;j++)
    {
        if(i%2!=0)//checks whether number is prime or not
        {
            var num=i.toString();//converts array into string using toString()
            var num2=j.toString();//converts array into string using toString()
            var n=num.split('').sort().join('').trim();
            var n1=num2.split('').sort().join('').trim();
            
            if(n==n1)//checks prime numbers whether they are anagram 
            {
                dq.push(i);
                dq.push(j);
                dq.display();

                
                console.log();
                console.log();
                break;
            }       
        }
    }
    
} 