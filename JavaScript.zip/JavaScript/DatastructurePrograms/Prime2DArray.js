/***********************************************************************************
 *  Purpose         : Print Prime numbers in 2D array
 *  @file           : Prime2DArray.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 ************************************************************************************/
var prime=[];//creates a array
for(var i=0;i<=1000;i++)
{ 
    for(j=2;j<=i;j++)
    {
        if(i==2)
        {
            prime.push(i);//pushes 2 in array
        }
        if(i%j==0)
        {     
            break;
        }
        else
        {
            prime.push(i);//pushes only prime numbers in array
            break;
        }
    }
}
for(var i=0;i<prime.length;i++)
{
    console.log(prime[i]);//prints prime numbers in 1D Array
}
console.log();

var arr=[];
console.log("Prime Numbers in 2D Array");
while(prime.length>0)
{
    arr.push(prime.splice(0,50));
    console.log();
}

console.log(arr);


