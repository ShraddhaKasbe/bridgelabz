class Stack
{
    constructor()
    {
        this.items=[];
        this.size=0
    }

    push(element)
    {
        this.items.push(element);
    }

    pop()
    {
        if(this.items.length==0)
        {
            return "underflow"
        }
        else
        {
            return this.items.pop();
        }
    }


    isEmpty()
    {
        return this.items.length=0;
    }
    peek() 
    {  
        return this.items[this.items.length - 1]; 
    } 
    isMatchingPair(ch1,ch2)
    {  
        if(ch1=='{' && ch2=='}')
        return true;

        else if(ch1=='[' && ch2==']')
        return true;

        else if(ch1=='(' && ch2==')')
        return true;
    
        else
        return false;
    }

    isParantheses(str)
    {
        var stack=[];
        for(var i=0;i<str.length;i++)
        {
            if(str[i]=='{' || str[i]=='[' || str[i]=='(')
            {
                stack.push(str[i]);
                console.log(stack);
            }
            
            if(str[i]=='}' || str[i]==']' || str[i]==')')
            {
                if(this.isEmpty())
                {
                    return false;
                }
                if (!this.isMatchingPair(stack.pop(),str[i])) 
                { 
                    return false;
                }
            }
        }

        if(this.isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    main()
    {
        var str='{[()]}';
        if(this.isParantheses(str))
        {
            console.log("Balanced");
        }
        else
        {
            console.log("Not balanced");
        }
    }

}
var st=new Stack();
console.log(st.main());