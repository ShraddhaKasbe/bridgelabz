
var Palindrome=require('./Dequeue.js');//requires Queue.js file to perform queue operations

function PalChecker(str)
{
    let dq=new Palindrome.Deque();
    for(var i=0;i<str.length;i++)
    {
        dq.addRear(str[i]);
    }
    console.log(dq);
    var equal = true;

    while (dq.size() > 1 && equal) 
    {
        var first = dq.removeFront();
        var last = dq.removeRear();

        if (first !== last) 
        {
            equal = false;
        }
    }

    return equal;
    
}
console.log(PalChecker('madam'));
console.log(PalChecker('shraddha')); 
console.log(PalChecker('level'));
