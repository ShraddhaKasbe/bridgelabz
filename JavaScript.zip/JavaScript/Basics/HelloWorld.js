var name="Shraddha";
console.log(name);
var n=name.length;
console.log(n);

