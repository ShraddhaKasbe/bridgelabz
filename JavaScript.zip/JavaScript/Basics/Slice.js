var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
const fs = require('fs');

let txtFile = "/home/bridgeit/Shraddha/Names.txt";
let str = fs.readFileSync(txtFile,'utf8');
console.log(str);
var slice=str.slice(0,str.length-1);
var data=slice.toLowerCase().split(' ').sort();
console.log(data);
var keyvalue=rl.question("Enter key word to be searched:",String1);
function String1(keyvalue)
{
    var key=keyvalue.toLowerCase();
    console.log("Key Element to search:"+key);
    var start=0;
    var last=data.length-1;
    while(start<=last)
    {
        midvalue=(last+start)/2;
        var mid=Math.floor(midvalue);
        if(data[mid].localeCompare(key)<0)
        {
            start=mid+1;
        }
        else if(data[mid].localeCompare(key)==0)
        {
            console.log("Element found");
            break
        }
        else
        {
            last=mid-1;
        }
    }
    if(start>last)
    {
        console.log("Element not found");
    }
}