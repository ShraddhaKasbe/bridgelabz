var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
function test()
{
    rl.question('Enter the size of your array: ',function(size)
    {
        arrayelements(size);
    });
}


    function arrayelements(size)
    {
        var arr=[];
        var len=parseInt(size);
        console.log("Enter array elements:");
        recurrsion(len);
        function recurrsion(len)
        {
            if(len>0)
            {   
                rl.question('',function(i)
                {
                    arr.push(parseInt(i));
                    len--;
                    recurrsion(len);
                });
            }
            else
            {
                rl.close();
                console.log("Unsorted Array:"+arr);
                for(var i=1;i<arr.length;i++)
                {
                    var key=arr[i];
                    var j=i-1;
                    while(j>=0 && arr[j]>key)
                    {
                        arr[j+1]=arr[j];
                        j--;
                    }
                    arr[j+1]=key;
                }
                console.log("Sorted Array:"+arr);
            }

        }
    }
test();
