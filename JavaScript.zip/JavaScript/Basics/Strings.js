var st=["panvel","vashi","belapur","kharghar"];
console.log("Unsorted Array of Strings:"+st);
var str=st.sort();
console.log("Sorted Aray of Strings:"+str);
var key="panvels";
console.log("Key Element:"+key)
var start=0;
var last=str.length-1;
while(start<=last)
{
    mid=(last+start)/2;
    var midvalue=Math.floor(mid);
    if(str[midvalue]<key)
    {
        start=mid+1;
    }
    else if(str[midvalue]==key)
    {
        console.log("Element Found");
        break;
    }
    else
    {
        last=mid-1;
    }   
}
if(start>last)
{
    console.log("Element not found");
}