
var readline = require('readline')

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

var response = rl.question('Whats your name : ', answer)

function answer(response) {
    console.log("Name:"+response);
}

