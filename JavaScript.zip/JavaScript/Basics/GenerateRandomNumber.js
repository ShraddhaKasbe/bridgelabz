var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
var num=rl.question("Enter range:",randomNum);
function randomNum(num)
{
    
    var arr=new Array(num);
  
    for(var i=0;i<arr.length;i++)
    {
        var r=Math.floor((Math.random()*arr.length)+1);
        arr[i++]=r;
    }
    for(var i=0;i<num;i++)
    {
        console.log(a[i]);
    }
}