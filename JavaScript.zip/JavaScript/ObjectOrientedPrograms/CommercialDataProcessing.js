/***********************************************************************************
 *  Purpose         : Commercial Data Processing for Stock
 *  @file           : CommercialDataProcessing.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

var fs = require('fs')
var customerclass=require('./StockPortFolio.js', 'utf-8'); //reading class file
var customerjson=fs.readFileSync('./Customer.json','utf-8');//reading customer json file
var companyjson=fs.readFileSync('./Company.json'); //reading company json file

var cust=JSON.parse(customerjson); //parsing customer json file to object

function StockOperation()
{
    console.log("Press 1 for Customer Login");//for customer registration
    console.log("Press 2 for Company Login");//for company registration
    /** *
     * @param accepts choice from user for performing stock operations
    
    */

    rl.question("Enter your option:",function(options) 
    {
        /* switch case for operations */ 
        switch(options)
        {
            case '1':
            console.log("****** USER REGISTRATION *****");// user selects 1 as customer
            console.log();
            loginCustomer();//calls loginCustomer function for user login
            
            break;

            case '2':
            console.log("****** COMPANY REGISTRATION *****");//user selects 2 as company
            console.log();
            loginCompany();//calls loginCompany function for company login
            break;


        }
    })
}StockOperation();


/* TRansaction to be performed by Customer*/
function CustomerTransaction()
{
    console.log();
    /** *
     * @param accepts choice from user for performing transactions for buying and selling shares
    
    */
                rl.question("Choose the transaction option from the following:"+"\n"+
                "Type buy to buy shares"+"\n"+"Type sell to sell shares"+"\n",function(transaction)
                {
                    console.log();
                    console.log();
                    /*switch case for buy and sell*/
                    switch(transaction)
                    {
                        case 'buy':
                                BuyShares();//calls this function if user selects buy
                                break;

                        case 'sell':
                                SellShares();//calls this function if user selects sell
                                break;

                    }
                 
                })
}
/*Customer Registration*/
function loginCustomer()
{
    let flag=0;
    /** *
     * @param accepts customer name
    
    */
    rl.question('Enter your name:',function(cust_name)
    {
        /*for loop for traversing json object to search name of the customer*/
        let len;
        for (const key in cust) {
            len=cust[key].length;
            if (cust.hasOwnProperty(key)) {
                cust[key].forEach(element => {
                    if(cust_name==element.cust_name)//checks whether user is already registered
                    {
                        CustomerTransaction();//if yes,calls this function
                        
                    }
                    else
                    {
                     flag++;
                        
                    }
                           
                  
                });
            }       
        }
        if(flag==len){
            console.log("Fill the details to register");
            addcustomer();   //calls this function if new user
        }
    })
}


/*function for adding customer to json object*/
function addcustomer()
{
    /** *
     * @param accepts user name
     * @param accepts share price
     * @param accepts no of shares
    
    */
    rl.question('Enter your name:',function(cust_name)
    {
        rl.question('Enter your price of shares:',function(SharePrice)
        {
            rl.question('Enter your shares:',function(noOfShares)
            {   /*creates object of class Customer*/
                let a=    new customerclass.Customer(cust_name,SharePrice,noOfShares);
                /*pushes name,price and no of shares to customer json object*/
                cust.customer.push(a);

                /*writes the data to file using stringify*/
                fs.writeFile('./Customer.json', JSON.stringify(cust), 'utf-8', function(err) {
                    if (err) throw err
                    })
                    
                CustomerTransaction();//calls this function for transaction
            })
        })                       
    })
}

/*function for Company login*/
function loginCompany()
{
    var comp=JSON.parse(companyjson);//parses json object
    let flag=0;
     /** *
     * @param accepts company symbol 
     */
    rl.question('Enter your Company Symbol:',function(symbol)
    {
    /*traversing the company json object to check whether comapny is already registered or not*/
        let len;
        for (const key in comp) {
            len=comp[key].length;
            if (comp.hasOwnProperty(key)) {
                comp[key].forEach(element => {
                    if(symbol==element.stock_symbol)
                    {
                        CompanyTransaction();//calls if company is already registered
                        
                    }
                    else
                    {
                     flag++;
                        
                    }
                           
                  
                });
            }       
        }
        if(flag==len){
            console.log("Fill the details to register");
            addCompany();   //calls if company is new
        }
    })
}

/*for company transaction*/
function CompanyTransaction()
{
    console.log();
    /** *
     * @param accepts choice from company to buy or sell shares
     */
                rl.question("Choose the transaction option from the following:"+"\n"+
                "Type buy to buy shares"+"\n"+"Type sell to sell shares"+"\n",function(transaction)
                {
                    console.log();
                    console.log();
                    switch(transaction)
                    {
                        case 'buy':
                            BuySharesCompany();//calls is company wants to buy shares
                                break;

                        case 'sell':
                                SellSharesComapny();//calls is company wants to sell shares
                                break;

                    } 
    })
}
/*Company registration*/
function addCompany()
{   
    var companyobj=JSON.parse(companyjson); //parses company json file
      /** *
     * @param accepts company symbol
     * @param accepts company name
     * @param accepts company shares
     */ 
    rl.question('Enter your company symbol: ',function(stock_symbol)
    {
    rl.question('Enter your company name:',function(name)
    {
        rl.question('Enter number of shares:',function(noOfShares)
        {
            rl.question('Enter share price per share:',function(SharePrice)
            {   
                /*pushes the data into company json object*/
                 companyobj.company.push(new customerclass.Company(stock_symbol,name,noOfShares,SharePrice));

                 /*writes the data to json file*/
                 fs.writeFile('./Company.json', JSON.stringify(companyobj), 'utf-8', function(err) {
                    if (err) throw err
                    })
                    CompanyTransaction()//calls company transaction
                })
            })
        })
    })  
                  
}

/*Buy Shares for customer*/
function BuyShares()
{
    var buy=JSON.parse(companyjson);//parses json file of company to object
    console.log("**** LIST OF COMPANIES ****");//displays list of company
    /*traverses the whole json object*/
    for (const key in buy) 
    {
        if (buy.hasOwnProperty(key)) 
        {
            buy[key].forEach(element => {
                console.log("Company Symbol:",element.stock_symbol);
                console.log("Company Name:",element.name);
                console.log("Comapny Shares:",element.noOfShares);
                console.log("Share price per share:",element.SharePrice);
                console.log();
            })
        }
    }
     /** *
     * @param accepts choice from user to buy shares from one of the company
     * @param accepts customer name
     * @param accepts company symbol
     * @param accepts no of shares to buy shares
     */
    console.log("Select the company to buy shares from by filling details");
    console.log();
    rl.question("Enter your name:",function(name)
    {
    rl.question("Enter Company symbol to buy shares from: ",function(stock_symbol)
    {
        rl.question("Enter number of shares to buy: ",function(noOfShares)
        {   
            /*traverses the company object*/   
            for (const key in buy) 
            {
                var temp=0;
                if (buy.hasOwnProperty(key)) 
                {
                    buy[key].forEach(element => {
                    if(stock_symbol==element.stock_symbol)//checks for match of user entered symbol and company symbol
                    {   /*if matches buy operation is performed */
                        console.log("Company Details before Transaction:",buy[key][temp]);  
                        var date=new Date();//getting current date
                        element.noOfShares=parseInt(element.noOfShares)-parseInt(noOfShares);
                        console.log();
                        console.log("Company details after transaction:",buy[key][temp]); 
                        /*transaction object to store transaction details of buy*/
                        element.transaction.push({
                            company_symbol:element.stock_symbol,
                            company_shares:element.noOfShares,
                            transaction_time:date
                        });
                        /*writes the pushed data to json file*/
                        fs.writeFile('./Company.json', JSON.stringify(buy), 'utf-8', function(err) {
                        if (err) throw err
            
                                })
                          
                    }
                    temp++;          
                  
                    });
                } 
            } 

            /*traverses the customer object*/   
            for (const key in cust) {
                var temp=0;
                if (cust.hasOwnProperty(key)) {
                    cust[key].forEach(element => {
                        if(name==element.cust_name)
                        {/*if name matches buy operation is performed */
                            console.log("Customer Details before transaction:",cust[key][temp]); 
                            var date=new Date();//getting current date
                            element.noOfShares=parseInt(element.noOfShares)+parseInt(noOfShares);
                            console.log();
                            console.log("Customer Details after transaction:",cust[key][temp]); 
                              /*transaction object to store transaction details of buy*/   
                            element.transaction.push({
                                cust_name:element.cust_name,
                                cust_shares:element.noOfShares,
                                transaction_time:date
                            });
                             /*writes the pushed data to json file*/
                            fs.writeFile('./Customer.json', JSON.stringify(cust), 'utf-8', function(err) {
                            if (err) throw err
            
                            })
                            return;
                                 
                            
                        }
                        temp++;          
                      
                    });
                }       
            
            }           
    })
    })
})
}
/*Buy Shares for Company*/
function BuySharesCompany()
{
    var buy=JSON.parse(companyjson);
    console.log("**** LIST OF CUSTOMERS ****");
    for (const key in cust) 
    {
        if (cust.hasOwnProperty(key)) 
        {
            cust[key].forEach(element => {
                console.log("Customer Name:",element.cust_name);
                console.log("Customer Shares:",element.noOfShares);
                console.log("Share price per share:",element.SharePrice);
                console.log();
            })
        }
    }
    console.log("Select the Customer to buy shares from by filling details");
    console.log();
    rl.question("Enter your Company name:",function(cname)
    {
    rl.question("Enter Customer name to buy shares from: ",function(cust_name)
    {
        rl.question("Enter number of shares to buy: ",function(noOfShares)
        {      
            for (const key in cust) 
            {
                var temp=0;
                if (cust.hasOwnProperty(key)) 
                {
                    cust[key].forEach(element => {
                    if(cust_name==element.cust_name)
                    {
                        console.log("Customer Details:",cust[key][temp]);  
                        var date=new Date();
                        element.noOfShares=parseInt(element.noOfShares)-parseInt(noOfShares);
                        console.log(cust[key][temp]);  
                        
                        element.transaction.push({
                            cust_name:element.cust_name,
                            cust_shares:element.noOfShares,
                            transaction_time:date
                        });
                        fs.writeFile('./Customer.json', JSON.stringify(cust), 'utf-8', function(err) {
                            if (err) throw err
                        
                            })
                        
                        return;
                    }
                    temp++;          
                  
                    });
                } 
            }      
            
            for (const key in buy) {
                var temp=0;
                if (buy.hasOwnProperty(key)) {
                    buy[key].forEach(element => {
                        if(cname==element.name)
                        {
                            console.log("Company Details:",buy[key][temp]); 
                            var date=new Date();
                            element.noOfShares=parseInt(element.noOfShares)+parseInt(noOfShares);
                            console.log(buy[key][temp]); 
                            element.transaction.push({
                                company_symbol:element.stock_symbol,
                                company_shares:element.noOfShares,
                                transaction_time:date
                            });
                            fs.writeFile('./Company.json', JSON.stringify(buy), 'utf-8', function(err) {
                                if (err) throw err
                            
                                })
                                
                                 
                        }
                        temp++;          
                      
                    });
                }       
            
            }
            
    })
    })
})
}


function SellShares()
{
    var sell=JSON.parse(companyjson);
    rl.question("Enter your name:",function(name){
        rl.question("Enter company symbol to sell shares to:",function(symbol){
            rl.question("Enter no of shares to sell:",function(noOfShares){

                for (const key in sell) 
                {
                var temp=0;
                if (sell.hasOwnProperty(key)) 
                {
                    sell[key].forEach(element => {
                    if(symbol==element.symbol)
                    {
                        console.log("Company Details:",sell[key][temp]);  
                        element.noOfShares=element.noOfShares+noOfShares;
                        console.log(sell[key][temp]);    
                        fs.writeFile('./Company.json', JSON.stringify(sell), 'utf-8', function(err) {
                            if (err) throw err
                        
                            })
                    }
                    temp++;          
                  
                    });
                } 
            }      

            for (const key in cust) {
                var temp=0;
                if (cust.hasOwnProperty(key)) {
                    cust[key].forEach(element => {
                        if(name==element.cust_name)
                        {
                            console.log("Customer Details:",cust[key][temp]); 
                            console.log(element.noOfShares); 
                            element.noOfShares=parseInt(element.noOfShares)-parseInt(noOfShares);
                            console.log(cust[key][temp]);   
                            fs.writeFile('./Customer.json', JSON.stringify(cust), 'utf-8', function(err) {
                                if (err) throw err
                            
                                }) 
                        }
                        temp++;          
                      
                    });
                }  
            }    
            })
        })
    })
}


function SellSharesComapny()
{
    var sell=JSON.parse(companyjson);
    rl.question("Enter your company name:",function(cname){
        rl.question("Enter customer name to sell shares to:",function(name){
            rl.question("Enter no of shares to sell:",function(noOfShares){

                for (const key in cust) 
                {
                var temp=0;
                if (cust.hasOwnProperty(key)) 
                {
                    cust[key].forEach(element => {
                    if(name==element.cust_name)
                    {
                        console.log("Customer Details:",cust[key][temp]);  
                        element.noOfShares=parseInt(element.noOfShares)+parseInt(noOfShares);
                        console.log(cust[key][temp]); 
                        fs.writeFile('./Customer.json', JSON.stringify(cust), 'utf-8', function(err) {
                            if (err) throw err
                        
                            })    
                    }
                    temp++;          
                  
                    });
                } 
            }      

            for (const key in sell) {
                var temp=0;
                if (sell.hasOwnProperty(key)) {
                    sell[key].forEach(element => {
                        if(cname==element.name)
                        {
                            console.log("Company Details:",sell[key][temp]); 
                            element.noOfShares=parseInt(element.noOfShares)-parseInt(noOfShares);
                            console.log(sell[key][temp]); 
                            fs.writeFile('./Comapny.json', JSON.stringify(sell), 'utf-8', function(err) {
                                if (err) throw err
                            
                                })    
                        }
                        temp++;          
                      
                    });
                }  
            }    
            })
        })
    })
}

