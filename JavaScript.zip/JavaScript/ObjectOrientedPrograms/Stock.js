/***********************************************************************************
 *  Purpose         : To print stock report with total value of each stock
 *  @file           : RejexExpression.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var stock=require('./StockPortFolio.js');

var readline=require('readline');
    const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
    });

var fs = require('fs')
var file=fs.readFileSync('./Stock.json', 'utf-8');

//let st=new stock.StockPortfolio();
function Stocks(){
rl.question("Enter number of stocks:",function(no_of_stocks)
{
    noOfStocks(no_of_stocks);
});
function noOfStocks(no_of_stocks)
{
    var data=JSON.parse(file);

    recurrsion(parseInt(no_of_stocks));

    function recurrsion(len)
    {
        if(parseInt(len)>0)
        {  
            rl.question('Enter Stock Name:',function(StockName)
            {
                rl.question("Enter no of shares:",function(No_of_Shares)
                {
                    rl.question("Enter share price:",function(SharePrice)
                    {
                        data.stock.push(new stock.StockPortfolio(StockName,No_of_Shares,SharePrice));
                        for (const key in data) {
                            var total;
                            var allTotal=0;
                            if (data.hasOwnProperty(key)) {
                                data[key].forEach(element => {
                                    total=element.No_of_Shares*element.SharePrice;
                                    console.log(element.StockName+' Total=',total);
                                    allTotal=allTotal+total;                                                    
                                  
                                });
                            }
                           
                                console.log("Total Price of all "+key ,allTotal);
                                console.log();
                        }
                        console.log();
                        len--;
                        recurrsion(len);
                    })
           
                })
            })
            fs.writeFile('./Stock.json', JSON.stringify(data), 'utf-8', function(err) {
                if (err) throw err
                })
        }
        else if(parseInt(len)==0)
        {
            rl.close();
            
            process.exit(0);
        }
    }
}}Stocks();