/***********************************************************************************
 *  Purpose         : Create a JSON file having Inventory Details 
 *  @file           : Inventory.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

var fs = require('fs')

fs.readFile('./Inventory.json', 'utf-8', function(err, data) {
	if (err) throw err
    var ricename=rl.question("Enter rice name:",RiceName);
    function RiceName(ricename)
    {
        var riceweight=rl.question("Enter rice weight:",RiceWeight);
        function RiceWeight(riceweight)
        {
            var riceprice=rl.question("Enter rice price:",RicePrice);
            function RicePrice(riceprice)
            {
                console.log();

                var pulsesname=rl.question("Enter Pulses name:",PulsesName);
                function PulsesName(pulsesname)
                {
                    var pulsesweight=rl.question("Enter pulses weight:",PulsesWeight);
                    function PulsesWeight(pulsesweight)
                    {
                        var pulsesprice=rl.question("Enter pulses price:",PulsesPrice);
                        function PulsesPrice(pulsesprice)
                        {
                            console.log();
                
                            var wheatname=rl.question("Enter Wheat name:",WheetName);
                            function WheetName(wheatname)
                            {
                                var wheatweight=rl.question("Enter Wheat weight:",WheatWeight);
                                function WheatWeight(wheatweight)
                                {
                                    var wheatprice=rl.question("Enter Wheat price:",WheatPrice);
                                    function WheatPrice(wheatprice)
                                    {

                                        var obj=JSON.parse(data);
                                        obj.rice.push({
                                            name:ricename,
                                            weight:riceweight,
                                            price:riceprice
                                        })

                                        obj.pulses.push({
                                            name:pulsesname,
                                            weight:pulsesweight,
                                            price:pulsesprice
                                        })

                                        obj.wheat.push({
                                            name:wheatname,
                                            weight:wheatweight,
                                            price:wheatprice
                                        })
                                        for (const key in obj) {
                                            var total;
                                            var allTotal=0;
                                            if (obj.hasOwnProperty(key)) {
                                                obj[key].forEach(element => {
                                                    total=element.price*element.weight;
                                                    console.log(element.name+' Total=',total);
                                                    allTotal=allTotal+total;                                                    
                                                  
                                                });
                                            }
                                           
                                                console.log("Total Price of all "+key ,allTotal);
                                                console.log();
                                        }
                                        console.log(obj);

                                    fs.writeFile('./Inventory.json', JSON.stringify(obj), 'utf-8', function(err) {
                                        if (err) throw err
                                    console.log('Done!')
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
   
})
