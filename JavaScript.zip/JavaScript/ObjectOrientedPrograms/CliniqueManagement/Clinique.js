/***********************************************************************************
 *  Purpose         : Clinique Management for doctors and patients
 *  @file           : Clinique.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

var fs = require('fs')
var doctorjson=fs.readFileSync('../CliniqueManagement/Doctor.json'); //reading json file of doctor
var patientjson=fs.readFileSync('../CliniqueManagement/Patient.json');//reading json file of patient
var apptclass=require('../CliniqueManagement/Appointment.js');//reading appointment class file


var doctobj=JSON.parse(doctorjson);//parse doctor json file into object
var patientobj=JSON.parse(patientjson);//parse patient json file into object

CliniqueManager();//start point of execution
function CliniqueManager()
{
    try
    {
    /*Clinique management options for user for doctor and patient*/
    rl.question('*** CLINIQUEUE MANAGEMENT OPERATIONS ***'+"\n"+"\n"+
    "1.Doctor Operations"+"\n"+
    "2.Patient Operations"+"\n"+"\n"+
    /**
     * @param accepts choice from user to perform either patient operations or doctor operations
     */
    "Enter your choice:",function(choice){

        switch(choice)
        {
            case "1":
                CliniqueDoctor();//calls for doctor operations
                break;

            case "2":
                CliniquePatient();//calls for patient operations
                break;

            case "3":
                process.exit(0);
        }

    })
}
catch(err)
{
    console.log(err);
}

}

/*function for doctor operations to be performed*/
function CliniqueDoctor()
{
    /*list of choices for user of doctor operations to perform*/
    rl.question("***** DOCTOR OPERATIONS ******"+"\n"+"\n"+
    "1.Add Doctor"+"\n"+
    "2.View Doctors"+"\n"+
    "3.Search Doctor"+"\n"+
    "4.Exit"+"\n"+"\n"+
    
    /**
     * @param accepts choice from user to perform doctor operations
     */
    "Enter your choice: ",function(choice){
        
        switch(choice)
        {
            case '1':
                addDoctor();//calls for doctor registration
                break;

            case '2':
                ViewDoctor();//calls to view list of doctors registered
                break;

            case '3':
                SearchDoctor();//calls for searching doctor 
                break;

            case '4':
                process.exit(0);

        }

    })  

}

/*function for adding doctor*/
function addDoctor()
{
    /**
     * @param accepts doctor id
     * @param accepts doctor name
     * @param accepts doctor's specialization
     * @param accepts doctor's availability
     */
    rl.question('Enter doctor ID:',function(d_id){
        rl.question('Enter doctor name:',function(d_name){
            rl.question('Enter specialization:',function(d_specialization){
                rl.question('Enter availability:',function(d_available){

                    /*pushes data of doctor to json object*/
                    let doc=new apptclass.Doctor(d_id,d_name,d_specialization,d_available);
                    doctobj.doctor.push(doc);

                    /*prints doctor details after added*/
                    console.log();
                    console.log("Doctor ID: ",d_id);
                    console.log("Doctor Name: ",d_name);
                    console.log("Doctor Specialization: ",d_specialization);
                    console.log("Doctor Availability: ",d_available);

                    console.log();
                    console.log("Doctor Added Successfully");
                    
                    fs.writeFile('../CliniqueManagement/Doctor.json', JSON.stringify(doctobj), 'utf-8', function(err) {
                        if (err) throw err
                        })
                        CliniqueDoctor();//calls for the doctor operations again
                })
            })
        })
    })
}

/*function for Searching doctor*/
function SearchDoctor()
{
   /*list of choices for searching doctor of user choice*/
    rl.question("***** SEARCH DOCTOR *****"+"\n"+
                "1.Search doctor by ID"+"\n"+          
                "2.Search doctor by name"+"\n"+           
                "3.Search doctor Specialization"+"\n"+
                "4.Exit"+"\n"+"\n"+

                "Enter your choice: ",function(option){

                /**
                 * @param accepts choice from user to search doctor
                 */
                switch(option)
                {
                    case '1':/*Searches doctor by ID*/
                    /**
                     * @param accepts id from user to search
                     */
                        rl.question('Enter doctor ID:',function(d_id){
                            /*traverses the doctor json object to check for id match*/
                            for (const key in doctobj) {
                                if (doctobj.hasOwnProperty(key)) {
                                    doctobj[key].forEach(element => {
                                        if(d_id==element.doct_id)//if id matches prints the details of doctor*/
                                        {
                                            console.log("Doctor Id: ",element.doct_id);
                                            console.log("Doctor Name: ",element.doct_name);
                                            console.log("Doctor Specialization: ",element.doct_specialization);
                                            console.log("Doctor Availabilty: ",element.doct_availability);
                                            console.log();
                                            CliniqueDoctor();
                                        }  
                                        else
                                        {
                                            /*if id doesnt matches prints the below statement*/
                                            console.log("Doctor details not found");
                                            CliniqueDoctor();
                                        }
                                    })
                                }
                            }
                            
                        })
                    break;

                    case '2':/*searches doctor by name*/
                     /**
                     * @param accepts name from user to search
                     */
                        rl.question('Enter doctor name:',function(d_name){
                            /*traverses to search for name match*/
                            for (const key in doctobj) {
                                if (doctobj.hasOwnProperty(key)) {
                                    doctobj[key].forEach(element => {
                                        if(d_name==element.doct_name)//if match found prints details
                                        {
                                            console.log("Doctor Id: ",element.doct_id);
                                            console.log("Doctor Name: ",element.doct_name);
                                            console.log("Doctor Specialization: ",element.doct_specialization);
                                            console.log("Doctor Availabilty: ",element.doct_availability);
                                            CliniqueDoctor();
                                            console.log();
                                        }  
                                        else
                                        {
                                            /*if match not found prints below statement*/
                                            console.log("Doctor details not found");
                                            CliniqueDoctor();
                                        }
                                    })
                                }
                            }
                            
                        })
                    break;
                    
                    case '3':/*Searches doctor by speacialization*/
                     /**
                     * @param accepts speacialization from user to search
                     */
                        rl.question('Enter doctor specialization:',function(d_special){
                            /*traverses to check match for specialization*/
                            for (const key in doctobj) {
                                if (doctobj.hasOwnProperty(key)) {
                                    doctobj[key].forEach(element => {
                                        if(d_special==element.doct_specialization)//if matches prints details
                                        {
                                            console.log("Doctor Id: ",element.doct_id);
                                            console.log("Doctor Name: ",element.doct_name);
                                            console.log("Doctor Specialization: ",element.doct_specialization);
                                            console.log("Doctor Availabilty: ",element.doct_availability);
                                            CliniqueDoctor();
                                            console.log();
                                        }  
                                        else
                                        {
                                            /*if match not found prints below statement*/
                                            console.log("Doctor details not found");
                                            CliniqueDoctor();
                                        }
                                    })
                                }
                            }
                               
                        })
                    break;

                    case '4':
                        process.exit(0);
                }
    })
}


/*function for Clinique patients operations*/
function CliniquePatient()
{
    /*provides list of choices to user to perform patient operations*/
    rl.question("***** PATIENT OPERATIONS ******"+"\n"+
    "1.Add Patient"+"\n"+
    "2.Search Patient"+"\n"+
    "3.Take Appointment"+"\n"+
    "4.View Patients"+"\n"+
    "5.Exit"+"\n"+"\n"+

    "Enter your choice: ",function(choice){
    /**
     * @param accepts choice from user fro above list of options
     */
        switch(choice)
        {
            case '1':
                addPatient();//calls for registeration of patient
                break;

            case '2':
                SearchPatients();//calls to search patients
                break;
            
            case '3':
                TakeAppointment();//calls to take appointment
                break;

            case '4':
                ViewPatients();//calls to view patients registered 
                break;

            case '5':
                process.exit(0);

        }

    })  

}



/*function to register patients*/
function addPatient()
{
    /**
     * @param accepts pateint's Id
     * @param accepts patient's name
     * @param accepts patient's age
     * @param accepts patient's disease
     */
    rl.question('Enter patient ID:',function(p_id){
        rl.question('Enter patient name:',function(p_name){
            rl.question('Enter patient age:',function(p_age){
                rl.question('Enter patient disease:',function(p_disease){
                    /*pushes patients details to json object*/
                    let pat=new apptclass.Patient(p_id,p_name,p_age,p_disease);
                    patientobj.patient.push(pat);
                    /*prints patient's details*/
                    console.log();
                    console.log("Patient ID: ",p_id);
                    console.log("Patient Name: ",p_name);
                    console.log("Patient age: ",p_age);
                    console.log("Patient Disease: ",p_disease);

                    console.log();
                    console.log("Patient Added Successfully");
                    CliniquePatient();
                    fs.writeFile('../CliniqueManagement/Patient.json', JSON.stringify(patientobj), 'utf-8', function(err) {
                        if (err) throw err
                        })
                })
            })
        })
    })
}

/*function for searching patients*/
function SearchPatients()
{
    /*list of options provided to user to search patient of user's choice*/
    rl.question("***** SEARCH PATIENT *****"+"\n"+"\n"+
                "1.Search patient by ID"+"\n"+
                "2.Search patient by name"+"\n"+
                "3.Exit"+"\n"+"\n"+

                "Enter your choice: ",function(option){
                /**
                 * @param accepts choice from user to search
                 */

                switch(option)
                {
                    case '1':/*Searches patient by ID*/
                       rl.question('Enter patient ID:',function(p_id){
                           /*traverses the patient object to search for id match*/
                            for (const key in patientobj) {
                                if (patientobj.hasOwnProperty(key)) {
                                    patientobj[key].forEach(element => {
                                        if(p_id==element.patient_id)
                                        {
                                            console.log("Patient Id: ",element.patient_id);
                                            console.log("Patient Name: ",element.patient_name);
                                            console.log("Patient Age: ",element.patient_age);
                                            console.log("Patient Disease: ",element.patient_disease);
                                            console.log();
                                            rl.question("Do you want to take appointment, yes or no? ",function(appoint){
                                                
                                                if(appoint=="yes")
                                                {
                                                    console.log();
                                                    TakeAppointment();
                                                }
                                                else
                                                {
                                                    CliniquePatient();
                                                    console.log();
                                                }
                                            })
                                            
                                        }  
                                        else
                                    {
                                        console.log("Patient details not found");
                                        CliniquePatient();
                                    }
                                    })
                                }
                            }
                            
                        })
                    break;

                    case '2':
                    rl.question('Enter patient name:',function(p_name){
                        for (const key in patientobj) {
                            if (patientobj.hasOwnProperty(key)) {
                                patientobj[key].forEach(element => {
                                    if(p_name==element.patient_name)
                                    {
                                        console.log("Patient Id: ",element.patient_id);
                                        console.log("Patient Name: ",element.patient_name);
                                        console.log("Patient Age: ",element.patient_age);
                                        console.log("Patient Disease: ",element.patient_disease);
                                        console.log();
                                        rl.question("Do you want to take appointment, yes or no? ",function(appoint){
                                                
                                            if(appoint=="yes")
                                            {
                                                console.log();
                                                TakeAppointment();
                                            }
                                            else
                                            {
                                                CliniquePatient();
                                                console.log();
                                            }
                                        })
                                        
                                        CliniquePatient();
                                    }  
                                    else
                                    {
                                        console.log("Patient details not found");
                                        CliniquePatient();
                                    }
                                })
                            }
                        }
                        
                    })
                    break;

                    case '3':
                        process.exit(0);
                }
    })
}



function TakeAppointment()
{
    rl.question("Enter doctor name: ",function(dname){
        rl.question('Enter patient name: ',function(pname){       
            rl.question("Enter appointment date:",function(apptdate){
            for (const key in doctobj) {
                if (doctobj.hasOwnProperty(key)) {
                    doctobj[key].forEach(element => {
                        if(dname==element.doct_name && element.apppointment.length<5)
                        {
                            if(apptdate==element.doct_availability)
                            {
                              
                                element.apppointment.push({
                                    doct_name:dname,
                                    patient_name:pname,
                                    apppointment_date:apptdate
                                })  
                                console.log("Your Appointment is fixed with "+dname+"at "+apptdate);
                                console.log();
                                CliniquePatient();
                                fs.writeFile('../CliniqueManagement/Doctor.json', JSON.stringify(doctobj), 'utf-8', function(err) {
                                    if (err) throw err
                                    })

                            }
                            else
                            {
                                console.log("Sorry doctor is not available today");
                                CliniquePatient();
                            }
                        }
                                              
                        })
                    }
                
                 }
             })
         })
    })
}

function ViewPatients()
{
    console.log("***** LIST OF PATIENTS ******");
    for (const key in patientobj) 
    {
        if (patientobj.hasOwnProperty(key)) 
        {
            patientobj[key].forEach(element => {
                console.log("Patient ID:",element.patient_id);
                console.log("Patient Name:",element.patient_name);
                console.log("Patient age:",element.patient_age);
                console.log("Patient Disease:",element.patient_disease);
                console.log();
                CliniquePatient();
            })
        }
    }
}

function ViewDoctor()
{
    console.log("***** LIST OF DOCTORS ******");
    for (const key in doctobj) 
    {
        if (doctobj.hasOwnProperty(key)) 
        {
            doctobj[key].forEach(element => {
                console.log("Doctor Id: ",element.doct_id);
                console.log("Doctor Name: ",element.doct_name);
                console.log("Doctor Specialization: ",element.doct_specialization);
                console.log("Doctor Availabilty: ",element.doct_availability);
                CliniqueDoctor();
            })
        }
    }
}