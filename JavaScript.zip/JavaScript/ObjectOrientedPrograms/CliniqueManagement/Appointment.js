
class Doctor 
{
    constructor(doct_id,doct_name,doct_specialization,doct_availability)
    {
        this.doct_id=doct_id;
        this.doct_name=doct_name;
        this.doct_specialization=doct_specialization;
        this.doct_availability=doct_availability;
        this.apppointment=[];
    }

    getDoctID()
    {
        return this.doct_id;
    }
    setDoctID(d_id)
    {
        this.doct_id=d_id;
    }
    getDoctName()
    {
        return this.doct_name;
    }
    setDoctName(d_name)
    {
        this.doct_name=d_name;
    }
    getDoctSpecialization()
    {
        return this.doct_specialization;
    }
    setDoctSpecialization(d_speacialist)
    {
        this.doct_specialization=d_speacialist;
    }
    getDoctAvailability()
    {
        return this.doct_availability;
    }
    setDoctAvailability(d_available)
    {
        this.doct_availability=d_available;
    }
}

class Patient 
{
    constructor(patient_id,patient_name,patient_age,patient_disease)
    {
        this.patient_id=patient_id;
        this.patient_name=patient_name;
        this.patient_age=patient_age;
        this.patient_disease=patient_disease;
    }
    getPatientID()
    {
        return this.patient_id;
    }
    getPatientName()
    {
        return this.patient_name;
    }
    getPatientAge()
    {
        return this.patient_age;
    }
    getPatientDisease()
    {
        return this.patient_disease;
    }
}
module.exports={
    Doctor,
    Patient
}