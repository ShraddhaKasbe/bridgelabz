/***********************************************************************************
 *  Purpose         : Classes exported to other files
 *  @file           : StockPortFolio.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

/*class for Stock report in Stock.js*/
class StockPortfolio
{
    constructor(StockName,No_of_Shares,SharePrice)
    {
        this.StockName=StockName;
        this.No_of_Shares=No_of_Shares;
        this.SharePrice=SharePrice;
    }
    getStockName()
    {
        return this.StockName;
    }
    setStockName(name)
    {
        this.StockName=name;
    }
    getShares()
    {
        return this.No_of_Shares;
    }
    setShares(shares)
    {
        this.No_of_Shares=shares;
    }
    getSharePrice()
    {
        return this.SharePrice;
    }
    setSharePrice(price)
    {
        this.SharePrice=price;
    }

}

class StockAccount
{
    
    constructor(stock_symbol,noOfShares,SharePrice)
    {
        this.stock_symbol=stock_symbol;
        this.noOfShares=noOfShares;
        this.SharePrice=SharePrice;
        this.transaction=[];
    }

    getSymbol()
    {
        return this.stock_symbol;
    }
    getShares()
    {
        return this.noOfShares;
    }
    getSharePrice()
    {
        return this.SharePrice;
    }


}
class Company extends StockAccount
{
    constructor(stock_symbol,name,noOfShares,SharePrice)
    {
        super(stock_symbol,noOfShares,SharePrice);
        this.name=name;
       
    }
    getName()
    {
        return this.name;
    }
}

class Customer 
{
    constructor(cust_name,SharePrice,noOfShares)
    {
        this.cust_name=cust_name;
        this.SharePrice=SharePrice;
        this.noOfShares=noOfShares;
        this.transaction=[];
    }

    getName()
    {
        return this.cust_name;
    }
    getSharePrice()
    {
        return this.SharePrice;
    }
    getNoofShare()
    {
        return this.noOfShares;
    }
}

module.exports={

    StockPortfolio,
    Customer,
    StockAccount,
    Company
    

}

