/***********************************************************************************
 *  Purpose         : Create Object Oriented Analysis and Design of a simple Address Book Problem.
 *  @file           : AddressBook.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

var fs = require('fs')
var userjson=fs.readFileSync('./Users.json'); //reads user json file
var personclass=require('./Person.js'); //reads person file to take properties of Person class
var personobj=JSON.parse(userjson);//parses the json file to object

/* Main Address function containing all operations*/ 
function AddressBook()
{
    /** *
     * @param accept choice from user for address book operation
     */
    try
    {
    rl.question("***** ADDRESS BOOK OPERATIONS ******"+"\n"+"\n"+
    "1.Add Contact"+"\n"+
    "2.Edit Contact"+"\n"+
    "3.Delete Contact"+"\n"+
    "4.View Contacts"+"\n"+"\n"+
    "Enter your choice: ",function(choice){
        
        switch(choice)
        {
            case '1':
                addContact();//calls for adding contact
                break;

            case '2':
                EditContact();//calls for editing contact 
                break;
            
            case '3':
                DeleteContact();//calls for deleting contact
                break;

            case '4':
                ViewContact();//calls for veiwing the contact
                break;

            case '5':
                process.exit(0);

        }

    })  
}
    catch(err)
    {
        console.log(err);
    } 
}
AddressBook();//calls this function first(flow of execution starts from here)


/*function for adding contact*/
function addContact()
{
    /**
     * @param accept first name
     * @param accept second name
     * @param accept address
     * @param accept mobile number
     */
    try
    {
        console.log();
    rl.question('Enter your first name:',function(firstname)
    {
        rl.question('Enter your last name:',function(lastname)
        {
            rl.question('Enter your address:',function(address)
            {  
                rl.question('Enter your mobile number:',function(phone)
                {
                    /*pushes data accepted from user to user json object*/
                let person=new personclass.Person(firstname,lastname,address,phone);
                personobj.users.push(person);

                /*writes the data to json file*/
                fs.writeFile('./Users.json', JSON.stringify(personobj), 'utf-8', function(err) {
                    if (err) throw err
                    })
                console.log("Contact Added Successfully!!")
                console.log();
                AddressBook();//calls function to again perform operation
                
                })
            })
        })                       
    })
}
catch(err)
{
    console.log(err);
}
}


/*Function for Edinting Contact*/
function EditContact()
{
    console.log();
    let flag=0;
   console.log("**** EDIT CONTACT ****");
   /**
    * @param accepts first name to verify contact
    */
   rl.question('Enter your first name:',function(name)
   {
       let len;
       for (const key in personobj) {
           len=personobj[key].length;
           if (personobj.hasOwnProperty(key)) {
            personobj[key].forEach(element => {
                   if(name==element.firstname)//checks whether json object firstname equal to user input
                   {
                       Edit(element);//calls this function if name matches
                       
                   }
                   else
                   {
                    flag++;
                       
                   }
                          
                 
               });
           }       
       }
       if(flag==len){
           console.log();
           console.log("Contact not found. Create contact to edit");
           addContact();   //calls function to again perform operation
       }
   })
}

/*function for editing individual fields of contact*/
function Edit(element)
{
    /** 
     * @param accepts option from user to edit
     */
    rl.question("Select the field to be edited from the following"+"\n"+"\n"+
                "1.Edit firstname"+"\n"+
                "2.Edit last name"+"\n"+
                "3.Edit address"+"\n"+
                "4.Edit Mobile Number"+"\n"+
                "5.Exit"+"\n"+"\n"+
                "Enter your choice: ",function(option){


                switch(option)
                {
                    case '1':/* edits firstname*/
                        console.log();
                        rl.question('Enter new first name:',function(fname){
                            element.firstname=fname;

                            fs.writeFile('./Users.json', JSON.stringify(personobj), 'utf-8', function(err) {
                                if (err) throw err
                                })

                            console.log("Your details are changed");
                            Edit(element);
                        })
                    break;

                    case '2':/* edits lastname*/
                        rl.question('Enter new last name:',function(lname){
                           element.lastname=lname;
                            fs.writeFile('./Users.json', JSON.stringify(personobj), 'utf-8', function(err) {
                                if (err) throw err
                                })
                            console.log("Your details are changed");
                            Edit(element);
                        })
                    break;
                    case '3':/* edits address*/
                        console.log();
                        rl.question('Enter new address:',function(add){
                           
                                element.address=add;
                                
                            fs.writeFile('./Users.json', JSON.stringify(personobj), 'utf-8', function(err) {
                                if (err) throw err
                                })
                            console.log("Your details are changed");
                            console.log(personobj);
                            Edit(element);
                        })
                    break;
                    case '4':/* edits mobile number*/
                        console.log();
                        rl.question('Enter new mobile number:',function(mob){
                            element.phone=mob;
                           
                            fs.writeFile('./Users.json', JSON.stringify(personobj), 'utf-8', function(err) {
                                if (err) throw err
                                })
                            console.log("Your details are changed");
                            Edit(element);
                        })
                    break;

                    case '5':
                        process.exit(0);
                }
    })
}

/*function for deleting contact*/
function DeleteContact()
{/**
 * @param accepts first name from userto delete contact
 */
console.log();
    rl.question('Enter your first name:',function(name)
   {
       let len;
       for (const key in personobj) {
           len=personobj[key].length;
           var index=0;
           /*traversing to get the contact and index to be deleted */
           if (personobj.hasOwnProperty(key)) {
            personobj[key].forEach(element => {
                   if(name==element.firstname)
                   {
                    console.log(personobj.users);
                    delete personobj.users[index];
                    personobj.users.splice(index,1);//splice method to delete 1 contact by getting index    
                    fs.writeFile('./Users.json', JSON.stringify(personobj), 'utf-8', function(err) {
                        if (err) throw err
                        }) 
                        console.log("Contact deleted Successfully");  
                         AddressBook();              
                   }
                  
                   else
                   {
                    index++;
                       
                   }
                          
                 console.log("Contact not found");
                 AddressBook();//calls function to again perform operation
               });
           }       
       }
       
   })
    
}
/*function to view contacts*/
function ViewContact()
{
    console.log();
    console.log("***** Address Book Contacts ******");
    console.log();
    for (const key in personobj) 
    {
        if (personobj.hasOwnProperty(key)) 
        {
            personobj[key].forEach(element => {
                console.log("First Name:",element.firstname);//prints first name
                console.log("Last Name:",element.lastname);//prints last name
                console.log("Address:",element.address);//prints address
                console.log("Mobile Number:",element.phone);//prints mobile number
                console.log();
            })
        }
    }
    AddressBook();//calls function to again perform operation
}