/***********************************************************************************
 *  Purpose         : Regular Expression Demonstration
 *  @file           : RejexExpression.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin, //input stream
    output:process.stdout //outputstream
});
/*Original message*/
var msg="Hello <<name>>,"+"\n"+
"We have your full name as <<full name>> in our system." + "\n"+
"your contact number is 91-xxxxxxxxxx." +"\n"+
"Please,let us know in case of any clarification Thank you BridgeLabz 01/01/2016. ";
console.log(msg);//fisrt prints original message
console.log();

var dt=new Date();
var date=dt.getDate() + "/" + (dt.getMonth() + 1) + "/" + dt.getFullYear();//gets current date

 /** *
     * @param accepts name
     * @param accepts Fullname
     * @param accepts mobile number
    */
var name=rl.question("Enter your first name:",Name);
function Name(name)
{
    var regname=new RegExp(/^([a-zA-Z]{3,20})$/);//regex for first name with min 3 and max 20 character
    if(regname.test(name))
    {
        var fname=rl.question("Enter your Fullname name:",FullName);
        function FullName(fname)
        {
            var regfname=new RegExp(/^[a-zA-Z_]+( [a-zA-Z_]+)*$/);//regex for full name with space
            if(regfname.test(fname))
            {
                var mobile=rl.question("Enter your mobile number:",MobileNumber);
                function MobileNumber(mobile)
                {
                    var mobileno=new RegExp(/^\d{10}$/);//regex for mobile number of 10 digit
                    if(mobileno.test(mobile))
                    {
                        console.log();
                        /*replace tha date with user input*/
                        msg=msg.replace(/<<name>>/i,name).replace(/<<full name>>/i,fname).replace(/xxxxxxxxxx/i,mobile)
                        .replace('01/01/2016',date);
                        console.log(msg);
                    }
                    else
                    {
                        console.log("Invalid mobile number");//prints if mobile number invalid
                    }

                }
            }
            else
            {
                console.log("Invalid fullname ");//prints if fullname invalid
            }
        }
    }
    else
    {
        console.log("Invalid user name");//prints if name invalid
    }
}

    
    
       