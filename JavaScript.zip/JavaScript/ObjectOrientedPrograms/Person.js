
/*class Person for Address Book file */
class Person {
    constructor(firstname,lastname,address,phone) {//constructor Person with 4 properties
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.phone=phone;
    }

    setFirstName(firstname) { //setter for firstname
        this.firstname = firstname;
    }
    
    setLastName(lastname) {//setter for lastname
        this.lastname = lastname;
    }
    
    setAddress(address) {//setter for address
        this.address = address;
    }
    
    setPhone(phone) {//setter for phone
        this.phone = phone
    }
    
    getFirstName() {//getter for firstname
        return this.firstname;
    }
    
    getLastName() {//getter for lastname
        return this.lastname;
    }
    
    getAddress() {//getter for address
        return this.address;
    }
    
    getPhone() {//getter for phone
        return this.phone;
    }    
}
/*exports class Person*/
module.exports={
    Person
}