/***********************************************************************************
 *  Purpose         : Shuffling deck of cards and distribute to 4 players
 *  @file           : DeckOfCards.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

class Cards                    //class cards with properties rank and suits
{
    constructor(rank,suits)   //constructor with properties
    {
        this.rank=rank;
        this.suits=suits;
    }

    getRank() //getter for rank property
    {
        return this.rank;
    }
    setRank(rank) //setter for rank property
    {
        this.rank=rank;
    }
    getSuits() //getter for suits property
    {
        return this.suits;
    }
    setSuits(suits)//setter for suits property
    {
        this.suits=suits;
    }

    toString() { 
        return '(' + this.rank + ', ' + this.suits + ')';
    }
}
class Player extends Cards      //class player extends Cards to use properties of cards class
{
    constructor(cards) //constructor for cards property
    {
        this.cards=cards;
    }

    getCards()          //getter for cards property
    {
        return this.cards;
    }
    setCards(cards)
    {
        this.cards=cards; //setter for cards property
    }

    toString()
    {
        return '(' + this.rank + ', ' + this.suits + ')';
    }
}

/*exports Cards and Player Classes*/
module.exports={
    Cards,
    Player
}