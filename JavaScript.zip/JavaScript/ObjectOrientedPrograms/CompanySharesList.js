/***********************************************************************************
 *  Purpose         : Adding shares and removing shares from company using linked list
 *  @file           : ComapnyShares.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

var file1=require('./StockPortFolio');//reading class file
var fs=require('fs');
var stockjson=fs.readFileSync('./StockAccount.json');//reading stock json file
var file=require('../DatastructurePrograms/LinkedList');//reading linked list file
console.log(file);
let list=new file.LinkedList();

LinkedListOperation();
function LinkedListOperation()
{
    console.log("****** Company Shares Operations *******");
    console.log("-----------------------------------------");
    console.log('1.Type add for adding the stock');
    console.log('2.Type remove for removing the stock');
    console.log('3.Type exit to exit the operations');
    console.log();
    rl.question("Enter your choice:",function(choice)
    {
        switch(choice)
        {
            case 'add':
                    add();
                    break;

            case 'remove':
                    remove();
                   break;
            
            case 'exit':
                        process.exit(0);
        }
    })
}

function add()
{
    rl.question('Enter Stock symbol:',function(symbol){
        rl.question('Enter no of shares:',function(noOfShares){
            rl.question('Enter share price:',function(price){
            var stock=new file1.StockAccount(symbol,noOfShares,price);
            list.add(stock);
            list.display();
            console.log(JSON.stringify(list));
            fs.writeFile('./StockAccount.json', JSON.stringify(list), 'utf-8', function(err) {
                if (err) throw err
            
                })
                LinkedListOperation();

            })
        })
    })
    
}

function remove() 
{
    var stock=new file1.StockAccount();
    var company=JSON.parse(stockjson);
    
    rl.question("Enter stock symbol: ",function(symbol)
    {
        for (const key in company) 
        {
            if (company.hasOwnProperty(key))
            {
                company[key].forEach(element => {
                    if(symbol==element.stock_symbol) 
                    {
                        list.remove(stock);
                        list.display();
                        console.log(JSON.stringify(list));

                        fs.writeFile('./StockAccount.json', JSON.stringify(list), 'utf-8', function(err) {
                        if (err) throw err
                
                        })
                    }  
                    
                    LinkedListOperation();    

                })
            }    
        }        

    })
}    

