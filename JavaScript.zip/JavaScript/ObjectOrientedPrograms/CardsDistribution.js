/***********************************************************************************
 *  Purpose         : Shuffling deck of cards and distribute to 4 players
 *  @file           : CardsDistribution.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

var fs=require('./DeckOfCards.js');//reading the Deck of Cards file

try{
    var rank=[2,3,4,5,6,7,8,9,10,'Jack','Queen','King','Ace'];//array for rank
    var suits=['Hearts','Diamonds','Spades','Clubs'];//array for suits
    var cards=[];//empty array to store cards
    Deck();//calling Deck function
    function Deck()
    {
        let k=0;//index for cards array
        for(let i=0;i<suits.length;i++)//for loop for suits
        {

        for(var j=0;j<rank.length;j++)//for loop for rank
        {
            cards.push(new fs.Cards( rank[j],suits[i]));//pushes the cards one by one in cards array
            k++;//increments cards array
        }
    }
    if(k==52){
    console.log(cards);//prints cards array after pushing array into cards
    }
    shuffle();//calls shuffle function
}

/*function for shuffling the cards*/
function shuffle()
{
    var swap,temp;
    console.log();
    console.log("Cards After Shuffle:");
    for(var i=cards.length;i>0;i--)//for loop to print array after shuffle
    {
        swap=Math.floor(Math.random() * i);//randomly shuffles the cards
        /*swaps the cards randomly*/
        temp=cards[i];
        cards[i]=cards[swap];
        cards[swap]=temp;

    }
    console.log(cards);//prints shuffled cards
    player();//calls player function 
}

/*function for distributing cards to 4 players*/
function player()
{
    player=[[],[],[],[]];//array for 4 players
    var k=0;
     console.log();
     console.log('Distribution of cards among players')
     
    for (var i = 0; i < 4; i++) {//for loop for rows
        for (var j = 0; j < 9; j++) {//for loop for columns
           
            player[i][j]=cards[k];// storing cards from card array into 2D player array
            k++;
            
        }
    }
    
    
}
console.log(player);//prints array after distribution of 9 cards to 4 players
}
catch(err)
{
    console.log(err);
}