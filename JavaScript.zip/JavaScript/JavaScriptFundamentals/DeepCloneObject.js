/***********************************************************************************
 *  Purpose         : Use of Deep Cloning object in JavaScript
 *  @file           : DeepCloneObject.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

let obj={
    a:1,
    b:{
        c:2,
    },
}
/*
    deep clone occurs when an object is copied along with the objects to which it refers
*/
let newObj=JSON.parse(JSON.stringify(obj));
obj.b.c=20;
console.log(obj);
console.log(newObj);
