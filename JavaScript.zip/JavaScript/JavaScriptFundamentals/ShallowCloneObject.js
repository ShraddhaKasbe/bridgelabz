/*/**********************************************************************************
 *  Purpose         : Use of Shallow clone object in JavaScript
 *  @file           : ShallowCloneObject.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
    -shallow clone creates a new object that has an exact copy of the values 
     in the original object
    -if any of fields of object are references to other objects, then only reference is copied
*/

//shallow clone example 1
/*
    obj created with values a:1 and b:1
*/
let obj={
    a:1,
    b:1
};
/*
    another object created using Object.assign() and copies values of object obj to new object
*/
let newObj=Object.assign({},obj);
console.log(newObj);



//shallow clone example 2
let Toyota={
    drive(){
        return 'Driving toyota';
    },

    park()
    {
        return 'Parking toyota';
    }
    
};

let Swift={
    drive(){
        return 'Driving Swift';

    }
};

Object.assign(Swift,Toyota);
console.log(Swift.drive());
console.log(Swift.park());
