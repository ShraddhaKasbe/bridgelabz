/*/**********************************************************************************
 *  Purpose         : Use of Function Chaining in JavaScript
 *  @file           : FunctionChaining.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

var Student=function()
{
    this.rollno=101;
    this.name="Shraddha";
    this.age=22;
    this.address="Seawoods" ;
};

/*
    Setting rollno
*/
Student.prototype.setRollno=function(rollno)
{
    this.rollno=rollno;
    return this;
};
/*
    Setting name
*/
Student.prototype.setName=function(name)
{
    this.name=name;
    return this;
}; 
/*
    Setting age
*/
Student.prototype.setAge=function(age)
{
    this.age=age;
    return this;
};
/*
    Setting address
*/
Student.prototype.setAddress=function(address)
{
    this.address=address;
    return this;
};
/*
    save function prints rollno,name,age and address
*/
Student.prototype.save=function()
{
    console.log("Roll No: "+this.rollno+ " Name: "+this.name+ 
    " Age: "+this.age+" Address: "+this.address);
    
    return this;
}

var stud=new Student();
/*
    Running multiple methods repeatedly one after another on same object
*/
stud.setRollno(102).setName("Shital").setAge(20).setAddress("Vashi").save();
