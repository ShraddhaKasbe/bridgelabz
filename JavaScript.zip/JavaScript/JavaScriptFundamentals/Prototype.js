/*/**********************************************************************************
 *  Purpose         : Use of Prototype in JavaScript
 *  @file           : Prototype.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
    --Prototype used for inheriting properties of parent function 
    --Parent function person with name as argument
*/
var person=function(name){
    this.setName=name;
};
/*
    add print () method to Person prototype property so that other objects can inherit it
*/
person.prototype.print=function()
{
    console.log("Hello "+this.setName);
};

/*
    Employee function inherits properties of parent function
*/
    var Employee=function(name,title){
    person.call(this,name); 
    this.setTitle=title
};
/*
    Object.create() creates a new object using exiting object to provide newly created 
    objects prototype
*/
Employee.prototype=Object.create(person.prototype);
Employee.prototype.print=function()
{
    console.log("Hello! My name is "+this.setName+ " I am "+this.setTitle);
};
/*
    Teacher function inherits properties of parent function
*/
var Teacher=function(name,schoolName){
    person.call(this,name);
    this.schoolName=schoolName;
};
Teacher.prototype=Object.create(person.prototype);
Teacher.prototype.print=function()
{
    console.log("Hello! My name is "+this.setName+ " I teach in "+this.schoolName);
};

var p=new person('Vaishnavi');
var e=new Employee('Ram','Developer');
var t=new Teacher('Priya','D.A.V. Public School');
p.print();
e.print();
t.print();




