/*/**********************************************************************************
 *  Purpose         : Use of Promise in JavaScript
 *  @file           : Promise.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

/*
  --Promise represents the completion or failure of an asynchronous operation 
    and its resulting value
  --function promise is passed with the arguments resolve and reject
  --resolve and reject functions when called resolve or reject the promise
*/
function printString(string){
    return new Promise((resolve, reject) => {
      setTimeout(
        () => {
         console.log(string)
         resolve()
        }, 
       Math.floor(Math.random() * 100) + 1
      )
    })
  }
  

function printAll(){
    printString("A")
    .then(() => {
      return printString("B")
    })
    .then(() => {
      return printString("C")
    })
  }
printAll();