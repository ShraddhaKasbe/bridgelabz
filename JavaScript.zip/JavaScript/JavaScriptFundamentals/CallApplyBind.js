/*/**********************************************************************************
 *  Purpose         : Use of Call Method, Apply Method and Bind Method in JavaScript
 *  @file           : CallApplyBind.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

console.log();
console.log("**** CALL METHOD ****");
var person=function(firstname,lastname)
{
    this.firstname=firstname;
    this.lastname=lastname;
};
/*
    call() method calls a function with a given this value and arguments provided individually
*/
var person1=function(firstname,lastname,age){
    person.call(this,firstname,lastname);
    this.age=age;
};

var person2=function(firstname,lastname,address){
    person.call(this,firstname,lastname);
    this.address=address;
};

var p=new person("Sita","Rao");
var p1=new person1("Ram","Sharma",30);
var p2=new person2("Laxman","Singh","Mumbai");
console.log(p);
console.log(p1);
console.log(p2);



/*
    apply() method calls a function with arguments provided as an array
*/
console.log();
console.log("**** APPLY METHOD ****");
var numbers=[20,51,3,18,36,6,9,15];
var max=Math.max.apply(numbers);
var min=Math.min.apply(numbers);
for(var i=0;i<numbers.length;i++)
{
    if(numbers[i]>max)
    {
        max=numbers[i];
    }
    if(numbers[i]<min)
    {
        min=numbers[i];
    }
}
console.log("Largest Number from array:" +max);
console.log("Smallest Number from array:"+min);



/*
    DIFFERENCE BETWEEN CALL METHOD AND APPLY METHOD
*/
console.log();
console.log("**** COMPARISON OF CALL METHOD AND APPLY METHOD ****");
var array=['a', 'b'];
var elements=[0, 1, 2];
var array1=['a', 'b'];
var elements1=[0, 1, 2];

/*
    call() takes any arguments separately 
*/
array1.push.call(array1,elements1);
console.log(array1);
/*
    apply() accepts a single array of arguments.
*/
array.push.apply(array, elements);
console.info(array); 


/*
    BIND METHOD
*/
console.log();
console.log("**** BIND METHOD ****");
 var person1={
    firstname:"Shraddha",
    lastname:"Kasbe"
 };

 var person2={
     firstname:"Shital",
     lastname:"Chaudhari"
 };

 function print()
 {
     console.log("FullName: "+this.firstname+ " "+" "+this.lastname); 
 }
/*
    bind() method creates a new bound function
*/
 var bindperson1=print.bind(person1);
 var bindperson2=print.bind(person2);
bindperson1();
bindperson2();
