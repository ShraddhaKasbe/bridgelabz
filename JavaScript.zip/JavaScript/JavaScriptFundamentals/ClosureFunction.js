/*/**********************************************************************************
 *  Purpose         : How closure function works in JavaScript
 *  @file           : ClosureFunction.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
var Name=function(firstName,lastName)
{ /*
        intro is the local variable of Name function
    */
    var intro="Your name is:";
    /*
        getFullname is the inner function
    */
    var getFullName=function()
    {
        /*   
            getFullName() accesses the outer function Name() variable intro
        */
        return intro+firstName+" "+lastName;
    }
    return getFullName;
}

showName=Name('Shraddha','Kasbe');
console.log(showName());