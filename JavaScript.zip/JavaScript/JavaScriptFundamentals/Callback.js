/*/**********************************************************************************
 *  Purpose         : Use of Callback Method in JavaScript
 *  @file           : Callback.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/

/*
    Callback function is passed into another function as an argument which is then 
    invoked inside the outer function to complete some kind of routine or action.
*/
 function printString(string,callback)
{
    setTimeout(
        ()=>{
            console.log(string);
            callback();
        },
        Math.floor(Math.random()*100)+1
    )
}
/*
    Due to callback the printString function will execute synchronously i.e(A->B->C)
*/
function printAll()
{
    printString("A",()=>{
        printString("B",()=>{
            printString("C",()=>{})
        })
    })
}
printAll();



