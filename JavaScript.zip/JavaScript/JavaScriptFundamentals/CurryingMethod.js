/*/**********************************************************************************
 *  Purpose         : Use of Currying Function in JavaScript
 *  @file           : CurryingMethod.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
     Normal Function
*/
var message=function(a,b,c)
{
    console.log("Messaging " +a+ " to " +b+ " using " +c);
}


/*
    Currying is a technique of evaluating function with multiple arguments, into
    sequence of function with single argument.

    function message takes one argument and returns another function with b as argument
    which then returns a function with c as argument
 */
var message=function(a)
{
    return function(b)
    {
        return function(c)
        {
            console.log("Messaging " +a+ " to " +b+ " using " +c);
        
        };
    };
};

var text=message('Good Morning')('Shraddha')('whatsapp');
/*
    INTERNAL WORKING
    var text=message('Good Morning')
    returns function('Shraddha')
    returns function('whatsapp')
    returns Messaging Good Morning to Shraddha using whatsapp
*/