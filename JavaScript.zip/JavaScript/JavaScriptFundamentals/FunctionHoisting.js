/*/**********************************************************************************
 *  Purpose         : Use of Function Hoisting in JavaScript
 *  @file           : FunctionHoisting.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
    Normal Function Calling after function declaration
*/
function name()
{
    console.log("Name is Rani");
};
name();


/*
 --function declaration hoisted
 --function called before it is declared
*/
say();
function say()
{
    console.log('Say Hi!');
}



/*
    function initialized and then called
*/
var add=function(a,b)
{
    console.log("Sum:"+(a+b));
};
add(2,4);



/*
    -error occurs because function declaration can be hoisted not the initialization
    in this example it is called before it is initialized
*/

person('Shraddha','Kasbe'); 
var person=function(firstname,lastname)
{
    console.log("FullName: "+firstname+" "+lastname);
};
 