/*/**********************************************************************************
 *  Purpose         : Print prime Palindrome numbers from 1-1000
 *  @file           : PrimePalindrome.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*/**********************************************************************************
 *  Purpose         : To print prime numbers that are palindrome
 *  @file           : PrimePalindrome.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/


var Utility=require('../Utility/Utility');//reading file from Utility folder
Utility.PrimePalindrome();//calling Primepalindrome function from Utility.js file from utility folder

