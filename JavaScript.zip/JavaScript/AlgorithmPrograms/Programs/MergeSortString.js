/*/**********************************************************************************
 *  Purpose         : Perform Merge sort on String
 *  @file           : MergeSortString.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
var Utility =require('../Utility/Utility');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
/*
    @param accept  array of elements in String to perform merge sort
*/
function test()
{
    rl.question('Enter the size of your array: ',function(size)
    {
        try
        {
            if(isNaN(size))throw ' Not a number' //throws exception when size is in string
            if(size<0) throw 'not a positive number' //throws exception when size is negative 
            arrayelements(size);//makes call to arrayelements function to take array elements from user
        }
        catch(err)
        {
            console.log(size+ " is "+err);
        }
        
    });
}

    function arrayelements(size)
    {
        var array=[];//initially array is empty
        var len=size;//initialized size of the array to the variable len
        console.log("Enter array elements:");//asks user to give array elements input
        recurrsion(len);//makes call to recurrsion function to take array elements of array size
        function recurrsion(len)
        {
            if(len>0)
            {   
                rl.question('',function(i)
                {
                    try
                    {
                        if(!isNaN(i))throw ' Not a string' //throws exception when element is integer
                        array.push((i));//stores array elements from user one by one recursively in array
                        len--;//decrements the array size
                        recurrsion(len);//recursive call to recurrsion function till len=0
                    }
                    catch(err)
                    {
                        console.log(err);//catches the exception thrown by try block
                    }
                });
            }
            else
            {
                rl.close();
                console.log("Array before merge sort: "+array);//prints unsorted array before merge sort
                Utility.mergeSort(array,0,array.length-1);//calls mergesort function from utility.js file
                console.log("Array after merge sort: "+array);
            }
        }
    }   
    test();//calls test function;
 
 

       