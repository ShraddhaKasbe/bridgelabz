/*/**********************************************************************************
 *  Purpose         : To perform Seraching and Sorting on strings and numbers
 *  @file           : SearchingSorting.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
var Utility =require('../Utility/Utility');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});
/*
    @param accept size of array and array elements for search and sort algorithms
*/
function test()
{
    rl.question('Enter the size of array for Integer : ',function(size)
    {
        try
        {
            if(isNaN(size))throw ' Not a number' //throws exception when size is in string
            if(size<0) throw 'not a positive number' //throws exception when size is negative 
            arrayelements(size);//makes call to arrayelements function to take array elements from user
        }
        catch(err)
        {
            console.log(size+ " is "+err);
        }
    });
}
function arrayelements(size)
{
    var arr=[];
    var len=size;
    console.log("Enter  integer elements for binary search :");
    recurrsion(len);
    function recurrsion(len)
    {
        if(len>0)
        {   
            rl.question('',function(i)
            {
                arr.push((i));
                len--;
                recurrsion(len);
            });
        }
        else
        {
            var start=new Date();
            var start_time=start.getMilliseconds();

            Utility.BinarySearchInteger(arr);//calls the function declared in Utility.js of Utility folder

            var stop=new Date();
            var stop_time=stop.getMilliseconds();
            var elapsedtime=stop_time-start_time;
            console.log("Elapsed time:"+elapsedtime);
            console.log();
            function test1()
            {
                rl.question('Enter the size of String array: ',function(size)
                    {
                        try
                        {
                            if(isNaN(size))throw ' Not a number' //throws exception when size is in string
                            if(size<0) throw 'not a positive number' //throws exception when size is negative 
                            arrayelements(size);//makes call to arrayelements function to take array elements from user
                        }
                        catch(err)
                        {
                            console.log(size+ " is "+err);
                        }
                    });
            }
            function arrayelements(size)
            {
                var arr=[];
                var len=size;
                console.log("Enter String elements for Binary Search :");
                recurrsion(len);
                function recurrsion(len)
                {
                    if(len>0)
                    {   
                        rl.question('',function(i)
                        {
                            arr.push((i));
                            len--;
                            recurrsion(len);
                        });
                    }
                    else
                    {
                        var start=new Date();
                        var start_time=start.getMilliseconds();
                        
                        Utility.BinarySearchString(arr);//calls the function declared in Utility.js of Utility folder

                        var stop=new Date();
                        var stop_time=stop.getMilliseconds();
                        var elapsedtime=stop_time-start_time;
                        console.log("Elapsed Time:"+elapsedtime)
                        console.log();
                        function test2()
                        {
                            rl.question('Enter the size of Integer array: ',function(size)
                                {
                                    try
                                    {
                                        if(isNaN(size))throw ' Not a number' //throws exception when size is in string
                                        if(size<0) throw 'not a positive number' //throws exception when size is negative 
                                        arrayelements(size);//makes call to arrayelements function to take array elements from user
                                    }
                                    catch(err)
                                    {
                                        console.log(size+ " is "+err);
                                    }
                                });
                        }
                        function arrayelements(size)
                        {
                            var arr=[];
                            var len=size;
                            console.log("Enter Integer elements for Insertion Sort :");
                            recurrsion(len);
                            function recurrsion(len)
                            {
                                if(len>0)
                                {   
                                    rl.question('',function(i)
                                    {
                                        arr.push((i));
                                        len--;
                                        recurrsion(len);
                                    });
                                }
                                else
                                {
                                    var start=new Date();
                                    var start_time=start.getMilliseconds();

                                    Utility.InsertionSortInteger(arr);//calls the function declared in Utility.js of Utility folder

                                    var stop=new Date();
                                    var stop_time=stop.getMilliseconds();
                                    var elapsedtime=stop_time-start_time;
                                    console.log("Elapsed Time:"+elapsedtime)
                                    console.log();
                                    function test3()
                                    {
                                        rl.question('Enter the size of String array: ',function(size)
                                            {
                                                try
                                                {
                                                    if(isNaN(size))throw ' Not a number' //throws exception when size is in string
                                                    if(size<0) throw 'not a positive number' //throws exception when size is negative 
                                                    arrayelements(size);//makes call to arrayelements function to take array elements from user
                                                }
                                                catch(err)
                                                {
                                                    console.log(size+ " is "+err);
                                                }
                                            });
                                    }
                                    function arrayelements(size)
                                    {
                                        var arr=[];
                                        var len=size;
                                        console.log("Enter String elements for Insertion Sort :");
                                        recurrsion(len);
                                        function recurrsion(len)
                                        {
                                            if(len>0)
                                            {   
                                                rl.question('',function(i)
                                                {
                                                    arr.push((i));
                                                    len--;
                                                    recurrsion(len);
                                                });
                                            }
                                            else
                                            {
                                                var start=new Date();
                                                var start_time=start.getMilliseconds();

                                                Utility.InsertionSortString(arr);//calls the function declared in Utility.js of Utility folder

                                                var stop=new Date();
                                                var stop_time=stop.getMilliseconds();
                                                var elapsedtime=stop_time-start_time;
                                                console.log("Elapsed Time:"+elapsedtime)
                                                console.log();
                                                function test4()
                                                {
                                                    rl.question('Enter the size of integer array: ',function(size)
                                                        {
                                                            try
                                                            {
                                                                if(isNaN(size))throw ' Not a number' //throws exception when size is in string
                                                                if(size<0) throw 'not a positive number' //throws exception when size is negative 
                                                                arrayelements(size);//makes call to arrayelements function to take array elements from user
                                                            }
                                                            catch(err)
                                                            {
                                                                console.log(size+ " is "+err);
                                                            }
                                                        });
                                                }
                                                function arrayelements(size)
                                                {
                                                    var arr=[];
                                                    var len=size;
                                                    console.log("Enter Integer elements for Bubble Sort :");
                                                    recurrsion(len);
                                                    function recurrsion(len)
                                                    {
                                                        if(len>0)
                                                        {   
                                                            rl.question('',function(i)
                                                            {
                                                                arr.push((i));
                                                                len--;
                                                                recurrsion(len);
                                                            });
                                                        }
                                                        else
                                                        {
                                                            var start=new Date();
                                                            var start_time=start.getMilliseconds();
                                                            
                                                            Utility.BubbleSortInteger(arr);//calls the function declared in Utility.js of Utility folder

                                                            var stop=new Date();
                                                            var stop_time=stop.getMilliseconds();
                                                            var elapsedtime=stop_time-start_time;
                                                            console.log("Elapsed Time:"+elapsedtime)
                                                            console.log();
                                                            function test5()
                                                            {
                                                                rl.question('Enter the size of string  array: ',function(size)
                                                                    {
                                                                        try
                                                                        {
                                                                            if(isNaN(size))throw ' Not a number' //throws exception when size is in string
                                                                            if(size<0) throw 'not a positive number' //throws exception when size is negative 
                                                                            arrayelements(size);//makes call to arrayelements function to take array elements from user
                                                                        }
                                                                        catch(err)
                                                                        {
                                                                            console.log(size+ " is "+err);
                                                                        }
                                                                    });
                                                            }
                                                            function arrayelements(size)
                                                            {
                                                                var arr=[];
                                                                var len=size;
                                                                console.log("Enter String elements for Bubble Sort :");
                                                                recurrsion(len);
                                                                function recurrsion(len)
                                                                {
                                                                    if(len>0)
                                                                    {   
                                                                        rl.question('',function(i)
                                                                        {
                                                                            arr.push((i));
                                                                            len--;
                                                                            recurrsion(len);
                                                                        });
                                                                    }
                                                                    else
                                                                    {
                                                                        var start=new Date();
                                                                        var start_time=start.getMilliseconds();

                                                                        Utility.BubbleSortString(arr);//calls the function declared in Utility.js of Utility folder       

                                                                        var stop=new Date();
                                                                        var stop_time=stop.getMilliseconds();
                                                                        var elapsedtime=stop_time-start_time;
                                                                        console.log("Elapsed Time:"+elapsedtime)
                                                                    }
                                                                }
                                                            }test5();        
                                                                   
                                                        }
                                                    }
                                                }test4();        
                                                       
                                            }
                                        }
                                    }test3();        
                                           
                                }
                            }
                        }test2();              
                    }
                }
            }test1();                 
        }
    }
}test();


