/*/**********************************************************************************
 *  Purpose         : Converting decimal to binary and binary to decimal by swapping nibbles 
 *  @file           : ToBinaryToDecimal.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});

/*
    @param accepts a number from user
*/
var num=rl.question("Enter a Number:",DecimalToBinary);
function DecimalToBinary(num)
{
    try
	{
		if(isNaN(num))throw 'Not a number'     //throws exception if input is in string 
        if(num<0)throw 'not a positive number' //throws exception if input is negative
        
        var toBinary=parseInt(num, 10).toString(2);//converts from decimal to binary
        console.log("Decimal to Binary:"+toBinary);

        var nibble1=toBinary.substring(0,toBinary.length/2);//divides the binary string in two halves
        console.log("Nibble 1:"+nibble1);

        var nibble2=toBinary.substring(toBinary.length/2,toBinary.length);
        console.log("Nibble 2:"+nibble2);

        var swapnibble=nibble2+nibble1;//swapping the nibbles and concatinate
        console.log("After swapping the number:"+swapnibble);

        var toDecimal=parseInt(swapnibble,2);//converting swapped binary to decimal
        console.log("Decimal to Binary of new number:"+toDecimal);
    }
    catch(err)
    {
        console.log(num+" is "+err);           //catches the exception thrown by try block
    }
}