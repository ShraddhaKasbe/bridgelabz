/*/**********************************************************************************
 *  Purpose         : Calculate monthly payment
 *  @file           : MonthlyPayment.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
/*
    @param accept principal amount
    @param accept Rate of Interest
    @param accept no of year
*/
var P=rl.question("Enter a Principal Amount:",principal);
function principal(P)
{
    try
    {
        if(isNaN(P))throw 'Not a number'//throws exception when principal is in string
        if(P<0)throw 'not a positive number'//throws exception when principal is negative 
    
        var R=rl.question("Enter Rate of Interest:",rate);
        function rate(R)
        {
            if(isNaN(R))throw 'Not a number'//throws exception when rate of interest is in string
            if(R<0)throw 'not a positive number'//throws exception when rate of interest is negative

            var Yr=rl.question("Enter no of Years:",year);
            function year(Yr)
            {
                if(isNaN(Yr))throw 'Not a number'//throws exception when no. of years is in string
                if(Yr<0)throw 'not a positive number'//throws exception when no. of years is negative

                var n=12*parseFloat(Yr);
                var r=parseFloat(parseFloat(parseFloat(R)*100)/12);
		        var payment=parseFloat((parseFloat(P)*parseFloat(r))/(1-Math.pow(1+parseFloat(r), parseFloat(-n))));
		        console.log("Monthly Payment:"+payment);//prints monthly payment
            }
        } 
    }
    catch(err)
    {
        console.log(err);//catches the exception thrown by try block
    }
        
}