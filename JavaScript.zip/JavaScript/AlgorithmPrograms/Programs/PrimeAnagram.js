/*/**********************************************************************************
 *  Purpose         : print prime numbers that are anagram
 *  @file           : PrimeAnagram.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
var Utility =require('../Utility/Utility');//reading file from Utility folder

Utility.PrimeAnagram();//calling PrimeAnagram function from Utility.js file from utility folder


 