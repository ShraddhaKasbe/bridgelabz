/*/**********************************************************************************
 *  Purpose         : Perform Bubble sort on Integer
 *  @file           : BubbleSortInteger.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

/*
    @param accept  array of elements in integer to perform bubble sort
*/
function test()
{
    
        rl.question('Enter the size of your array: ',function(size)
        {
            try
            {
                if(isNaN(size))throw 'not a number'//throws this exception if input is string
                arrayelements(size);//calling arrayelements()function with argument size
            }
            catch(err)
            {
                console.log(err);
            }
        });
        
    
}

/*function declaration of arrayelements(size)*/
    function arrayelements(size)
    {
        var arr=[];
        var len=parseInt(size);
        
            console.log("Enter array elements:");//asking user for array elements
            recurrsion(len);//calling recurrsion()
            function recurrsion(len)
            {
                    if(len>0)
                    {   
                        rl.question('',function(i)
                        {
                            arr.push(parseInt(i));
                            len--;
                            recurrsion(len);
                        });
                    }
                    else
                    {
                        rl.close();
                        /*Bubble Sort Logic*/
                        for(var i=0;i<arr.length;i++)
                        {
                            for(var j=0;j<arr.length;j++)
                            {
                                if(arr[j]>arr[j+1])//checks whether first number > second number
                                {
                                    var temp=arr[j];//swaps the greatest number with smallest one using temp variable
                                    arr[j]=arr[j+1];
                                    arr[j+1]=temp;
                                }
                            }
                        }

                        console.log("Sorted Array after Bubble sort:");
                        for(var i=0;i<arr.length;i++)
                        {
                            console.log(arr[i]);//prints sorted list
                        }
                    }
                }
                
                         
    }
    test();//calling test function