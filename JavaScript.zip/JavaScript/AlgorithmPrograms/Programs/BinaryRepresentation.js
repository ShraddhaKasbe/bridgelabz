/*/**********************************************************************************
 *  Purpose         : To convert decimal number to binary
 *  @file           : BinaryRepresentation.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

/*
    @param accept a decimal number from user and convert it to binary
*/
var num=rl.question("Enter a Number:",DecimalToBinary);
function DecimalToBinary(num)
{
    try
    {
        if(isNaN(num))throw 'not a number'//throws if input is string
        if(num<0)throw 'not a positive number'//throws if input is negative

        var bin=[];//array to store binary number
        var k=0;
        while(num>0)//loop will iterate till num=0
        {
            bin[k++]=parseInt(num)%2;//calculates and stores modulus num by 2 in array and increments array index 
            num=Math.floor(num/2);//divides number by 2 and stores quetiont in num
        }
        for(var i=k-1;i>=0;i--)//reversly printing binary number
        {
            console.log(bin[i]);//prints binary number
        }	
    }
    catch(err)
    {
        console.log(num+" is "+err);//executes when exception thrown by try block
    }
}
