/***********************************************************************************
 *  Purpose         : compute the square root of a nonnegative number 
 *  @file           : SquareRoot.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
/*
	@param accept a number and calculate square root of it
*/
var c=rl.question("Enter a Number:",sqrt);
function sqrt(c)
{
	try
	{
		if(isNaN(c))throw 'Not a number'     //throws exception if input is in string
		if(c<0)throw 'not a positive number' //throws exception if input is negative
		var t=c;
		var epsilon=Math.pow(10,-15);// epsilon=1e-15

		while(Math.abs(t-c/t)>epsilon*t)
		{
			t=(c/t+t)/2;   //formula to calculate square root
		}
		
		console.log("Square root of number "+c+" is:"+t);//prints square root of the entered number
	}
	catch(err)
	{
		console.log(c+" is "+err);//catches the exception thrown by try block
	}
}