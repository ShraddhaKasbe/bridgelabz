/*/**********************************************************************************
 *  Purpose         : Calculate minimum number of returns from vending machine as change
 *  @file           : FewestNotes.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
const readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});

/*
    @param accept the amount from user
*/
var amount=rl.question("Enter the amount:",NotesCal);
function NotesCal(amount)
{
    try
    {
        if(isNaN(amount))throw 'Not a number' //throws exception when amount is in string
        if(amount<0)throw 'not a positive number'//throws exception when amount is negative
    
        var notes=[1,2,5,10,50,100,500,1000];//storing the types of notes in array
        var calNotes;
        var rem;
        var i=notes.length-1;

        /* while loop to iterate to get the number of notes*/
        while(i>=0) 
        {
            calNotes=Math.floor(parseInt(amount)/parseInt(notes[i]));//calculating no. of notes required from array
            rem=amount%notes[i];                                     //storing modulus of amount in rem
            amount=rem;                                              //assign value of rem to amount to again iterate
   
            if(calNotes!=0)                                          //checks for notes required
            {
                console.log("No of "+notes[i]+ " rupees notes required for change:"+calNotes);//prints the notes required of particular type from array
                //decrementing array index      
            }
            i--;   
        }
    }
    catch(err)
    {
        console.log(amount+ " is "+err); //executes when exception thrown by try block
    }
    
}
