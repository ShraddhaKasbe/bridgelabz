/*/**********************************************************************************
 *  Purpose         : Guess the number you are thinking of
 *  @file           : FindNumber.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
const readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
/*
    @param accepts a number to decide the range of prediction
*/

var powerValue=rl.question("Enter a number:",FindNumber);
function FindNumber(powerValue)
{
    try
    {
        if(isNaN(powerValue))throw ' Not a number' //throws exception when powervalue is in string
        if(powerValue<0) throw 'not a positive number' //throws exception when powervalue is negative 

        var n=Math.pow(2,powerValue);//calculates the range by 2^num 
        var num=new Array(n);//Initialization of a array of size 2^num
        for(var i=0;i<n;i++)
        {
            num[i]=new Array(n);// creating empty array 
        }
        for(var i=0;i<n;i++)
        {
            num[i]=i; //storing values of i in array
        }

        var low=0;//initaillly low=0
        var high=num.length-1; //initially high=num.length-1
        console.log("Choose a number between "+low+ " and " +high);//asks user to choose a number between the range
        BinarySearch(low,high); //calls BinarySearch function to guess the number with high and low value
    }
    catch(err)
    {
        console.log(powerValue+ "is "+err); //executes when exception thrown by try block
    }
}

function BinarySearch(low,high) 
{
    var mid=Math.floor((high+low)/2);//calculates the mid value from the range    
    if(high-low==0)
    {
        console.log("Your Number is:"+mid);//displays the final answer
        return;
    }
    var reply=rl.question("Is it less than "+mid+ " ?",Search) 
    /*asks whether number falls between the range in boolean value */
    function Search(reply)
    {
        var boolean="true";
        /*checks if reply is true or false*/
        if(reply==boolean) 
        {
            BinarySearch(low,mid);//if true calls BinarySearch function with low and mid
        }
        else if(reply=="false")
        {
            BinarySearch(mid,high);;//if false calls BinarySearch function with mid and high
        }
        else
        {
            console.log("Please enter either true or false");//prints if value entered is not boolean
        }
       
    }
}