/*/**********************************************************************************
 *  Purpose         : To perform binary search on strings read from a file 
 *  @file           : BinaryRepresentation.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});
const fs = require('fs');//reading local file

let txtFile = "../../../Names.txt";//relative path of the file
let str = fs.readFileSync(txtFile,'utf8');//readFileSync used to read a file,storing file in a string str 
console.log(str);
var slice=str.slice(0,str.length-1);//slice() to exclude new line(\n)
var data=slice.toLowerCase().split(' ').sort();//sorting the file strings and converting them to lowercase
console.log(data);

/*
    @param Accepting key value from user to search for in file
*/

var keyvalue=rl.question("Enter key word to be searched:",String1);
function String1(keyvalue)
{
    try
    {
        if(!isNaN(keyvalue))throw 'is not a string'
        var key=keyvalue.toLowerCase();//converting key to lower case
        console.log("Key Element to search:"+key);
        /*binary search logic*/
        var start=0;//start index of array of strings of file
        var last=data.length-1;//last index of array of strings of file
        while(start<=last)
        {
            midvalue=(last+start)/2;//caluclates mid value
            var mid=Math.floor(midvalue);
            /*compares whether key element present in an array*/
            if(data[mid].localeCompare(key)<0)//checks if key element is greater than mid
            {
                start=mid+1; //moves start index to mid+1
            }
            else if(data[mid].localeCompare(key)==0)//checks if key element and mid element are equal
            {
                console.log("Element found at "+mid+" position");//prints element found
                break
            }
            else//if key element is less than mid element
            {
            last=mid-1; //moves last pointer to mid-1
            }return this.items.length;
        }
        if(start>last)
        {
            console.log("Element not found");//prints when element is not present in array
        }
    }
    catch(err)
    {
        console.log("Entered Key "+keyvalue+" "+err);//executes when exception thrown by try block
    }
}