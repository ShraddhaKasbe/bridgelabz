/*/**********************************************************************************
 *  Purpose         : Insertion  Sort on array of strings
 *  @file           : InsertionSortString.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
/*
    @param accept  array of elements in string to perform insertion sort
*/
function test()
{
    rl.question('Enter the size of your array: ',function(size)
    {
        try
        {
            if(isNaN(size))throw ' Not a number' //throws exception when size is in string
            if(size<0) throw 'not a positive number' //throws exception when size is negative 
            arrayelements(size);//makes call to arrayelements function to take array elements from user
        }
        catch(err)
        {
            console.log(size+ " is "+err);
        }
        
        
    });
}


    function arrayelements(size)
    {
        var arr=[];//initially array is empty
        var len=parseInt(size);//initialized size of the array to the variable len
        console.log("Enter array elements:"); //asks user to give array elements input
        recurrsion(len);//makes call to recurrsion function to take array elements of array size
        function recurrsion(len)
        {
            if(len>0)
            {   
                rl.question('',function(i)
                {
                    try
                    {
                        if(!isNaN(i))throw ' Not a string' //throws exception when element is integer
                        arr.push(i);//stores array elements from user one by one recursively in array
                        len--;//decrements the array size
                        recurrsion(len);//recursive call to recurrsion function till len=0
                    }
                    catch(err)
                    {
                        console.log(err);//catches the exception thrown by try block
                    }
                });
            }
            else
            {
                rl.close();
                console.log("Unsorted Array:"+arr);//prints unsorted array
                /*INSERTION SORT LOGIC*/

                for(var i=1;i<arr.length;i++)//for loop with index i=1to traverse the array till array length-1
                {
                    var key=arr[i];//storing values of array in key
                    var j=i-1;//initializing another index j with i-1;
                    while(j>=0 && arr[j]>key)//compares the key element with elements before it
                    {
                        arr[j+1]=arr[j];//if key element < any of the element before it swaps the position
                        j--;
                    }
                    arr[j+1]=key;
                }
                console.log("Sorted Array:"+arr);//prints sorted array
            }
        }
    }
    test();//calls test function



