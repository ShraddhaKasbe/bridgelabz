/*/**********************************************************************************
 *  Purpose         : Print prime numbers from 1-1000
 *  @file           : PrimeNumber.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/


var Utility =require('../Utility/Utility');//reading file from Utility folder

Utility.PrimeNumber();//calling PrimeNumber function from Utility.js file from utility folder