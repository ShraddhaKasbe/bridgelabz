/*/**********************************************************************************
 *  Purpose         : Calculate Day of the Week from the given date
 *  @file           : DayOfTheWeek.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

/*
    @param Accept day, month and year fro user to calculate day of week
*/
try
{
var d=rl.question("Enter a Day:",Day);
function Day(d)
{
    if(d<=31 && d>0)
    {
        var m=rl.question("Enter a month:",month);
        function month(m)
        {
            if(m<=12 && m>0)
            {
                var y=rl.question("Enter a year:",year);
                function year(y)
                {
                    if(y<10000 && y>1000)
                    {
                        var y0 = Math.floor(y-((14 -m) / 12));
                        var x = y0 + Math.floor(y0/4) - Math.floor(y0/100) + Math.floor(y0/400);
                        var m0=parseInt(m)+12 *parseInt((14-parseInt(m))/12)-2;
                        var d0=parseInt(parseInt(parseInt(d) + parseInt(x) + 31 * parseInt(parseInt(m0)/12) )% 7);
                        
                        if(d0==0)
		                {
			                console.log("It's Sunday");
		                }
		                else if(d0==1)
		                {
			                console.log("It's Monday");
		                }
		                else if(d0==2)
		                {
			                console.log("It's Tuesday");
		                }
		                else if(d0==3)
		                {
			                console.log("It's Wednesday");
		                }
		                else if(d0==4)
		                {
			            console.log("It's Thursday");
		                }
		                else if(d0==5)
		                {
			                console.log("It's Friday");
		                }
		                else
		                {
			                console.log("It's Saturday");
		                }
                    }
                    else
                    {
                        console.log("Please Enter a valid year");//prints if year is in string or out of range
                    }

                }
            }
            else
            {
                console.log("Please Enter a valid month");//prints if month is in string or out of range
            }

        }
    }
    else
    {
        console.log("Please Enter a valid Day");//prints if day is in string or out of range
    }
            
    }
}
catch(err)
{
    console.log(err);//executes when exception thrown by try block
}

     
