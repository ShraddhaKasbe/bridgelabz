/***********************************************************************************
 *  Purpose         : To check whether two strings are anagram or not
 *  @file           : AnagramString.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/

var readline=require('readline');
var Utility =require('../Utility/Utility');//reading file from Utility folder
const rl=readline.createInterface({
    input:process.stdin,  //input stream
    output:process.stdout //output stream
});

/*
    @param accept two strings from user to check whether they are anagram
*/
try
{
    var str1=rl.question("Enter first string:",String1);
    function String1(str1)
    {
        var str2=rl.question("Enter second string:",String2);
        function String2(str2)
        {
        
        Utility.AnagramString(str1,str2);//calls the function declared in Utility.js of Utility folder
        }
    }
}
catch(err)
{
    console.log(err);         //executes when exception thrown by try block
}

