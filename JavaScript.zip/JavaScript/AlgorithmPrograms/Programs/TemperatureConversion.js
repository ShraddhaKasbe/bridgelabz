/*/**********************************************************************************
 *  Purpose         : Convert the temperature from fahrenheit to Celsius or viceversa
 *  @file           : TemperatureConversion.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/
/*
 *readline module provides an interface for reading data from a Readable stream one line 
*/
var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,
    output:process.stdout
});
/*
    @param accept the temperature from user
*/
var temp=rl.question("Enter a temperature:",temperature);
function temperature(temp)
{
    try
	{
		if(isNaN(temp))throw 'Not a number'     //throws exception if input is in string 
        
        var Fahrenheit= (temp * 9/5) + 32;      //converting from celsius to fahrenheit
        console.log("Conversion of Temperature from Celsius to Fahrenheit:"+Fahrenheit);
        var Celsius=(Fahrenheit - 32)*5/9;      //converting from fahrenheit to celsius
        console.log("Conversion of Temperature from Fahrenheit to Celsius:"+Celsius);
    }
    catch(err)
    {
        console.log(temp+" is "+err);           //catches the exception thrown by try block
    }
    
}