/***********************************************************************************
 *  Purpose         : Performing Binary search,Insertion sort and bubble sort 
 *  @file           : Utility.js
 *  @author         : Shraddha Kasbe
 *  @version        : 1.0
 *  @since          : 12-09-2018
 **********************************************************************************/


/****************************** ANAGRAM STRING*************************************/
/*function declarations with two parameters from other file(Anagram.js)*/
function AnagramString(str1,str2)
{
    try
    {
        if(str1.length!=str2.length)//checks whether length of the strings are equal or not
        {
            console.log("Strings are not anagram");//prints if strings not equal in length
        }
        else
        {
            /*
                --converting strings to lowercase by using toLowerCase() method
                --converting strings to arrays using split() method
                --sorts two strings using sort()
                --joining the strings using join('') method
                --triming the spaces from start and end of strings using trim()method
                
            */
            var s1 = str1.toLowerCase().split('').sort().join('').trim();
            var s2 = str2.toLowerCase().split('').sort().join('').trim();

                if(s1==s2)//after sorting checks whether two strings are equal or not
                {
                    console.log("Strings are anagram");//prints if both strings are equal after sort
                }
                else
                {
                    console.log("Strings are not anagram");//prints if strings are not equal
                }
            
        }
    }
    catch(err)
    {
        console.log(err);//executes when exception thrown by try block
    }
}
/***************************** PRIME NUMBER 1-1000 **************************************/

var util=require('util');//used to print ouput in single line
function PrimeNumber()
{ 
    for(var i=2;i<=1000;i++)//for loop for printing prime numbers from 2
    {

        try
        {
            if(i>1000)throw 'out of range'//throws if range is >1000
        }
        catch(err)
        {
            console.log(err);//catches the exception thrown by try block
        }
        var isprime=true;//initally isprime is true
        for(var j=2;j<i-1;j++)//j loop for printing prime numbers
        {
            try
            {
                if(i>1000)throw 'out of range'//throws if range is >1000
            }   
            catch(err)
            {
                console.log(err);
            }
            if(i%j==0)//checks whether number is prime or not
            {
               isprime=false;//returns false if number is not prime number(excludes that number & moves to other)
               break;
            }
        }
        if(isprime)//returns true if number is prime
        {
            util.print(i+" ");//prints prime number
        }
    }
}

/***************************** PRIME ANAGRAM NUMBER 1-1000 *********************************/

function PrimeAnagram()
{
    console.log("Prime Numbers that are Anagram:");
    for(var i=0;i<1000;i++)
    {
        for(var j=i+1;j<1000;j++)
        {
            if(i%2!=0)//checks whether number is prime or not
            {
                var num=i.toString();//converts array into string using toString()
                var num2=j.toString();//converts array into string using toString()
                var n=num.split('').sort().join('').trim();
                var n1=num2.split('').sort().join('').trim();
            
                if(n==n1)//checks prime numbers whether they are anagram 
                {
                     console.log(i+" - "+j);//prints prime anagram numbers
                }
            }
        }
    
    }
}


/***************************** PRIME PALINDROME NUMBER 1-1000 *********************************/

function PrimePalindrome()
{
    console.log("Prime Numbers that are palindrome:");
    for(var i=11;i<1000;i++)
    {
        if(i==11 || i%2!=0)//checks for prime numbers starting from 11 to check prime palindrpme number
        {
            /*palindrome logic*/
            var n= i;
            var rev = 0, rem;
            while (n>0)
            {
                rem = n % 10;
                rev = rev * 10 + rem ;
                n = Math.floor(n/10);
            } 
            if(rev==i)//checks if reversed number and the actual is same.i.e, palindrome
            {
                 console.log(i);//prints prime palindrome numbers
            }
         }
    }
}





/***************************** BINARY SEARCH FOR INTEGER *********************************/

function BinarySearchInteger(arr)
{
    console.log("*** BINARY SEARCH FOR INTEGER ***");
    var a=arr.sort();//sorts the array elements if it is not sorted for binary search
    console.log("Sorted Array:"+a);//prints sorted array
    var key=12;//key element to be searched from the array
    console.log("Key Element to search:"+key);//prints the key

    var start=0;//start index of array=0
    var last=a.length-1;//last index of array=a.length-1

    while(start<=last)
    {
        var mid=parseInt((start+last)/2);//calculates the mid value
        if(a[mid]<key)
        {
             start=mid+1;//moves if mid element < key element
        }
        else if(a[mid]==key)
        {
            console.log("Element Found at "+mid+" position");//prints if element found with position
            return;
        }
        else
        {
            last=mid-1;//moves if mid element > key element
        }
    }
    
    if(start>last)
		{
             console.log("Element not found");//prints if element not present in the array
             return;
           
        }
};


/***************************** BINARY SEARCH FOR STRING *********************************/

console.log();

function BinarySearchString(arr)
{
    console.log("*** BINARY SEARCH FOR STRING ***");
    console.log("Unsorted Array of Strings:"+arr);
    var str=arr.sort();//sorts the array elements if it is not sorted for binary search
    console.log("Sorted Array of Strings:"+str);//prints sorted array
    var key='seawoods';//key element to be searched from the array
    console.log("Key Element:"+key)//prints key element

    var start=0;//start index of array=0
    var last=str.length-1;//last index of array=a.length-1
    while(start<=last)
    {
        mid=parseInt((last+start)/2);//calculates the mid value
        if(str[mid]<key)
        {
             start=mid+1;//moves if mid element < key element
        }
        else if(str[mid]==key)
        {
            console.log("Element Found at "+mid+" position");//prints if element found with position
            break;
        }
        else
        {
             last=mid-1;//moves if mid element > key element
        }   
    }
    if(start>last)
    {
        console.log("Element not found");//prints if element not present in the array
    }
    
    
};


/***************************** INSERTION SORT FOR INTEGER *********************************/

console.log();

function InsertionSortInteger(arr)
{
    console.log("*** INSERTION SORT FOR INTEGER ***");
    console.log("Unsorted Array:"+arr);
    for(var i=1;i<arr.length;i++)
    {
        var key=arr[i];
        var j=i-1;
        while(j>=0 && arr[j]>key)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=key;
    }
    console.log("Sorted Array After applying insertion sort:"+arr);
}

/***************************** INSERTION SORT FOR STRING *********************************/

function InsertionSortString(arr)
{
    console.log("*** INSERTION SORT FOR STRING ***");
    console.log("Unsorted Array:"+arr);
    for(var i=1;i<arr.length;i++)
    {
        var key=arr[i];
        var j=i-1;
        while(j>=0 && arr[j]>key)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=key;
    }
    console.log("Sorted Array:"+arr);
};

/***************************** BUBBLE SORT FOR INTEGER *********************************/

console.log();

function BubbleSortInteger(arr)
{
    console.log("*** BUBBLE SORT FOR INTEGER ***");
    console.log("Unsorted array:"+arr)
    for(var i=0;i<arr.length;i++)
    {
        for(var j=0;j<arr.length;j++)
        {
            if(arr[j]>arr[j+1])
            {
                var temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    console.log("Sorted array="+arr);
};



/***************************** BUBBLE SORT FOR STRING *********************************/

console.log();

function BubbleSortString(arr)
{
    console.log("*** BUBBLE SORT FOR STRING ***");
    console.log("Unsorted Array:"+arr);
    for(var i=0;i<arr.length;i++)
    {
        for(var j=0;j<arr.length;j++)
        {
            if(arr[j]>arr[j+1])
            {
            var temp=arr[j];
            arr[j]=arr[j+1];
            arr[j+1]=temp;
            }
        }
    }
console.log("Sorted Array:"+arr);
}

/***************************** MERGE SORT FOR STRING *********************************/
function mergeSort(array,l,r)
{
    if(l<r)
    {
        var mid=Math.floor((l+r)/2);
        mergeSort(array,l,mid);
        mergeSort(array,mid,l);
        merge(array,l,mid,r);
    }
}

function merge(array,l,mid,r)
{
    var leftarr=mid-l+1
    var rightarr=r-mid; 
    var left=new Array(leftarr);
    var right=new Array(rightarr);
    for(var i=0;i<leftarr;i++)
    {
        left[i]=array[l+i];
    }      
    for(var j=0;j<rightarr;j++)
    {
        right[j]=array[mid+1+j];  
    }
    
    var i=0;
    var j=0;
    var k=0;
    
    while(i<leftarr && j<rightarr)
    {
        if(left[i].localeCompare(right[j])<0)
        {
            array[k]=left[i];
            i++;
        }
        else
        {
            array[k]=right[j];
            j++;
        }
            k++;
    }
    while(i<leftarr)
    {   
        array[k]=left[i];
        i++;
        k++;
    }
    while(j<rightarr)
    {
        array[k]=right[j];
        j++;
        k++;
    }
}

                    
                
            


module.exports={
    AnagramString,
    PrimeNumber,
    PrimeAnagram,
    PrimePalindrome,
    BinarySearchInteger,
    BinarySearchString,
    InsertionSortInteger,
    InsertionSortString,
    BubbleSortInteger,
    BubbleSortString,
    mergeSort
};