
var fs = require("fs");

var contents = fs.readFileSync("json1.json");

var jsonContent = JSON.parse(contents);

console.log("User Name:", jsonContent.username);
console.log("Email:", jsonContent.email);
console.log("Password:", jsonContent.password);
