class student
{
    constructor(rollno,name)
    {
        this.name=name;
        this.rollno=rollno;
    }
    getStudName()
    {
        return this.name;
    }
    getStudRollno()
    {
        return this.rollno;
    }
}
var s=new student(45,'shraddha');
console.log(s.getStudName());
console.log(s.getStudRollno());