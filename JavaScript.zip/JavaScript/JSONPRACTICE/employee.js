var readline=require('readline');
const rl=readline.createInterface({
    input:process.stdin,   //input stream
    output:process.stdout  //output stream
});

var fs = require('fs')

fs.readFile('./employee.json', 'utf-8', function(err, data) {
    if (err) throw err
    
    var name=rl.question("enter name:",TakeName);
    function TakeName(name)
    {
        var sal=rl.question("enter sal:",Salary);
        function Salary(sal)
        {
            var arrayOfObjects = JSON.parse(data)
            arrayOfObjects.employees.push({name:name})
            arrayOfObjects.employees.push({sal:sal})
            console.log(arrayOfObjects);
    
            fs.writeFile('./employee.json', JSON.stringify(arrayOfObjects), 'utf-8', function(err) {
            if (err) throw err
            console.log('Done!')
            })
        }
    }
    
})

