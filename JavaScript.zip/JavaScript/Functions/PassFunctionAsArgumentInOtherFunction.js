//In the following code our function receives a function defined by a function
// expression and executes it for every element of the array received as a second argument. 
function map(f,a) 
{
    var result=[],i; //create an array
    for(i=0;i<a.length;i++)
    {
        result[i]=f(a[i]);
    }
    return result;
}

var f=function(x)
{
    return x*x*x;
} 

var num=[4,2,5,3];
var cube=map(f,num);
console.log(cube);