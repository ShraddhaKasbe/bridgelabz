function myFunction(a, b) {
    return a * b;
}
console.log(myFunction(10, 2));  //invoking a function