function Student(n)
{
    n.name="Shraddha";
}
var stud={name:"Shital",rollno:20};
var x,y;
x=stud.name;
console.log(x);// x holds value shital 

Student(stud)
y=stud.name; // y holds shraddha as stud property gets changed
console.log(y);