//function without name can be stored in a variable and known as anonynous function
var add=function(a,b)  
{
    return a+b;
};

var x=add(2,2);
console.log(x);

//function can be given as a name and store in a variable to refer to itself
var factorial=function fac(n)
{
    return n<2?1:fac(n-1);
};
var result=factorial(3);
console.log(result);
