var obj=function()
{
    this.i=1;
    this.add=function(i)
    {
        this.i+=i;
        return this; //must return object of function
    };

    this.sub=function(i)
    {
        this.i-=i;//must return object
        return this; //must return object of function
    };

    this.print=function()
    {
        console.log(this.i);
    };
};

var x=new obj();
x.add(3).sub(2).print(); //function chaining