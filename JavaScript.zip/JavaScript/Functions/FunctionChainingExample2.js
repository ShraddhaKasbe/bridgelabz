var kitten=function()
{
    this.name="tweety";
    this.color="white";
    this.gender="female";
};

kitten.prototype.setName=function(name)
{
    this.name=name;
    return this;
};

kitten.prototype.setColor=function(color)
{
    this.color=color;
    return this;
};

kitten.prototype.setGender=function(gender)
{
    this.gender=gender;
    return this;
};

kitten.prototype.save=function()
{
    console.log('saving ' + this.name + ', the ' +
    this.color + ' ' + this.gender + ' kitten');
    return this;
};

var tom=new kitten();
tom.setName("Tom").setColor("Brown").setGender("male").save();