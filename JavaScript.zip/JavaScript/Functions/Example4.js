/* In JavaScript, a function can be defined based on a condition.
For example, the following function definition defines myFunc only if num equals 0: */

var f;
var num=0;
if(num===0)
{
    f=function(obj)
    {
        obj.name="abc";
    }
}