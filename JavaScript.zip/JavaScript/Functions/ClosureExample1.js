

var pet=function(name) {  //outer function defines a variable called "name"
  
var getName=function(){ //inner function has access to the 'name' variable of the outer function

        return name;
    }
    return getName; //return the inner function, thereby exposing it to outer scopes
}
   


myPet=pet('Tom');
console.log(myPet()); //returns 'Tom'