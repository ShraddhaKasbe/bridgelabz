function sqrt(num)
{
    return num*num;
}
var ans=sqrt(2);
console.log(ans);
