package Algorithm_Programs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Utility 
{
	/*ANAGRAM STRING OR NOT*/
	public static void isAnagram(String s1,String s2)
	{
		if(s1.length()!=s2.length())
		{
			
			System.out.println("Strings are not Anagram");	
			
		}
		else
			{
				char c1[]=s1.toCharArray();
				char c2[]=s2.toCharArray();
				Arrays.sort(c1);
				Arrays.sort(c2);
				for(int i=0;i<c1.length;i++)
				{
					if(c1[i]==c2[i])
					{
						System.out.println("Strings are Anagram");
						break;
					}
					else
					{
						System.out.println("Strings are not Anagram");
						break;
					}
				}							
				
		    }
	 }
	/*PRIME NUMBER BETWEEN 1-1000*/
	public static void primeNumber()
	{
		for(int i=1;i<1000;i++)
		{
			boolean isprime=true;
			for(int j=2;j<i-1;j++)
			{
				if(i%j==0)
				{
					isprime=false;
					break;
				}
				
			}
			if(isprime)
			{
				System.out.print(i+" ");
			}
		}
	}
	

	/* Prime Palindrom Number and Prime Anagram Number*/
	public static boolean isPrime(int number) 
	{
		if (number < 2) {
			return false;
		}	
		for (int i = 2; i * i <= number; i++) 
		{
			
			if (number % i == 0) {
				return false;

			}
		} 
		return true;
	}
	public static boolean isPalindrome(String str) 
	{
		char arr[] = str.toLowerCase().toCharArray();
		boolean isPalindrome = true;
		int j = arr.length - 1;
		for (int i = 0; i < arr.length; i++, j--) 
		{
			if (arr[i] == arr[j]) 
			{
				isPalindrome = true;
			} else 
			{
				isPalindrome = false;
				return isPalindrome;
			}
		}
		return isPalindrome;

	}
	
	public static boolean isAnagram1(String lString1, String lString2) 
	{
		boolean isAnagram = true;
		char charArray1[] = lString1.toLowerCase().toCharArray();
		char charArray2[] = lString2.toLowerCase().toCharArray();
		Arrays.sort(charArray1);
		Arrays.sort(charArray2);
		if (charArray1.length != charArray2.length) 
		{
			return false;
		} 
		else 
		{
			for (int i = 0; i < charArray1.length; i++) {
				if (charArray1[i] == charArray2[i]) {
					isAnagram = true;
				} else {
					isAnagram = false;
					break;
				}

			}
		}
		return isAnagram;
	}
	
	/** check the prime number is palindrome or not
	 * 
	 */
	public static void printPrimePalindrome()
	{
		System.out.println("Palindrome Prime number:");
		for (int lNumber = 2; lNumber < 1000; lNumber++)
		{
			if (isPrime(lNumber))
			{
				if (isPalindrome(Integer.toString(lNumber))) 
				{
					System.out.print(lNumber+" ");
				}
			}
		}
	}
	/**
	 * check the prime number is anagram or not
	 */
	public static void primeAnagram() 
	{
		ArrayList<String> primes = new ArrayList<>();
		System.out.println();
		System.out.println("Anagram Prime Numbers");
		for (int i = 0; i < 1000; i++) 
		{
			if (isPrime(i)) 
			{
				primes.add(String.valueOf(i));
			}
		}
		for (int i = 0; i < primes.size(); i++) 
		{
			for (int j = i + 1; j < primes.size(); j++) 
			{
				if (isAnagram1(primes.get(i), primes.get(j)))
				{
					System.out.println(primes.get(i) + "-" + primes.get(j));
				}
			}
		}
	}
	
	
	/*BINARY SEARCH, BUBBLE SORT, INSERTION SORT*/
	/*BINARY SEARCH FOR INTEGER*/
	public static void BinarySearchInteger()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array for binary search:");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("Enter Array elements in sorted order:");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("Enter the key to search an element:");
		int key=sc.nextInt();
		int start=0;
		int last=size-1;
		int mid=(start+last)/2;
		while(start<=last)
		{
			if(a[mid]<key)
			{
				start=mid+1;
			}
			else if(a[mid]==key)
			{
				System.out.println("Element "+key+" found at position "+mid);
				break;
			}
			else
			{
				last=mid-1;
			}
			mid=(start+last)/2;
		}
		
		if(start>last)
		{
			System.out.println("Element not found");
		}
	}
	
	/*BINARY SEARCH FOR STRING*/
	public static void BinarySearchString() throws IOException
	{
		Scanner sc=new Scanner(System.in);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the size of array:");
		int size=sc.nextInt();
		String names[]=new String[size];
		System.out.println("Enter Strings into array:");
		for(int i=0;i<size;i++)
		{
			names[i]=br.readLine();
		}
		System.out.print("Sorted Array of Strings:");
		for(int i=0;i<names.length;i++)
		{
			Arrays.sort(names);
			System.out.print(names[i]+" ");
		}
		System.out.println();
		System.out.println("Enter the key to search an element:");
		String key=br.readLine();
		int i=0;
		int j=names.length-1;
		int mid=(i+j)/2;
		
			while(i<=j)
			{
				if(names[mid].compareTo(key)>0)
				{
					j=mid-1;
				}
				else if(names[mid].compareTo(key)<0)
				{
					i=mid+1;
				}
				else
				{
					System.out.println("Element "+key+" found at position "+mid);
					break;
				}
				mid=(i+j)/2;
		}
		if(i>j)
		{
			System.out.println("Element not found");
		}
		
	}
	
	/*INSERTION SORT FOR INTEGER*/
	public static void InsertionSortInteger()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of the array:");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("Enter array elements:");
		for(int i=0;i<size;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("Sorted Array after insertion sort:");

		for(int j=1;j<a.length;j++)
		{
			int key=a[j];
			int i=j-1;
			while(i>-1 && a[i]>key)
			{
				a[i+1]=a[i];
				i--;
			}
			a[i+1]=key;	
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}		
	}
	
	/*INSERTION SORT FOR STRING*/
	public static void InsertionSortString() throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array size:");
		int size=sc.nextInt();
		String s[]=new String[size];
		System.out.println("Enter Strings into Array:");
		for(int i=0;i<size;i++)
		{
			s[i]=br.readLine();
		}
		System.out.println("Sorted String Array after Insertion Sort:");
		for(int j=1;j<s.length;j++)
		{
			int i=j-1;
			String key=s[j];
			while(i>-1 && s[i].compareTo(key)>0)
			{
				s[i+1]=s[i];
				i--;
			}
			s[i+1]=key;	
		}
		
		for(int i=0;i<s.length;i++)
		{
			System.out.print(s[i]+" ");
		}
	}
	
	/*BUBBLE SORT FOR INTEGER*/
	public static void BubbleSortInteger()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array size:");
		int size=sc.nextInt();
		int a[]=new int[size];
		System.out.println("Enter array elements:");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<a.length;i++)
		{
			for(int j=1;j<a.length-1;j++)
			{
				if(a[j-1]>a[j])
				{
					int temp=a[j-1];
					a[j-1]=a[j];
					a[j]=temp;
				}
			}
		}
		System.out.println("Sorted Array after Bubble Sort:");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
	
	/*BUBBLE SORT FOR STRING */
	public static void BubbleSortString() throws IOException
	{
		Scanner sc=new Scanner(System.in);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Array size: ");
		int size=sc.nextInt();
		String s[]=new String[size];
		System.out.println("Enter String array elements in Array:");
		for(int i=0;i<s.length;i++)
		{
			s[i]=br.readLine();
		}
		for(int i=0;i<s.length;i++)
		{
			for(int j=1;j<s.length;j++)
			{
				if(s[j-1].compareTo(s[j])>0)
				{
					String temp=s[j-1];
					s[j-1]=s[j];
					s[j]=temp;
				}
			}
		}
		System.out.println("Sorted String elements after Bubble Sort:");
		for(int i=0;i<s.length;i++)
		{
			System.out.print(s[i]+" ");
		}
	}
	
	/*BINARY SEARCH FOR WORDS FROM FILE*/
	public static void BinarySearchForWords() throws IOException
	{
		Scanner sc=new Scanner(System.in);
		String filename="/home/bridgeit/Shraddha/Names.txt";
		File file=new File(filename);
		FileInputStream fis=new FileInputStream(file);
		InputStreamReader isr=new InputStreamReader(fis);
		BufferedReader br=new BufferedReader(isr);
		ArrayList<String> list=new ArrayList<String>();
		String line;
		while((line=br.readLine()) != null)
		{
			System.out.println(line);
			String[] names=line.split(",");
			for(int i=0;i<names.length;i++)
			{
				list.add(names[i]);
				System.out.print(names[i]+" ");
			}	
			
			System.out.println();
			System.out.println();
			
			Arrays.sort(names);
			System.out.println("Sorted array of String:");
			for(int i=0;i<names.length;i++)
			{
				System.out.print(names[i]+" ");
			}
			
			System.out.println();
			System.out.println();
			System.out.println("Enter key element to search:");
			String key=sc.nextLine();
			int i=0;
			int j=names.length-1;
			int mid=(i+j)/2;
		
			while(i<=j)
			{
				if(names[mid].compareTo(key)>0)
				{
					j=mid-1;
				}
				else if(names[mid].compareTo(key)<0)
				{
					i=mid+1;
				}
				else
				{
					System.out.println("Element "+key+" found at position "+mid);
					break;
				}
				mid=(i+j)/2;
			}
			if(i>j)
			{
				System.out.println("Element not found");
			}
		
		}
	}
	
	
	/*MERGE SORT FOR STRING*/
	public static void MergeSort(String s[],int l,int r)
	{
		if(l<r)
		{
			int mid=(l+r)/2;
			MergeSort(s,l,mid);
			MergeSort(s,mid,r);
			merge(s,l,mid,r);
		}
		
	}
	
	public static void merge(String s[],int l,int mid,int r)
	{
		int n1=mid-l+1;
		int n2=r-mid;
		String temp1[]=new String[n1];
		String temp2[]=new String[n2];
		for(int i=0;i<n1;i++) 
		{
			temp1[i]=s[l+i];
		}
		for(int j=0;j<n2;j++)
		{
			temp2[j]=s[mid+1+j];
		}
		
		int i=0;
		int j=0;
		int k=l;
		while(i<n1 && j<n2)
		{
			if(temp1[i].compareTo(temp2[i])<=0)
			{
				s[k]=temp1[i];
				i++;
			}
			else
			{
				s[k]=temp2[j];
				j++;
			}
		}
		
		while(i<n1)
		{
			s[k]=temp1[i];
			i++;
			k++;
		}
		
		while(j<n2)
		{
			s[k]=temp2[j];
			j++;
			k++;
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

