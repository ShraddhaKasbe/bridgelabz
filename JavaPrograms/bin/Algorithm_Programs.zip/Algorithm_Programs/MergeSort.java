package Algorithm_Programs;

import java.util.Scanner;

public class MergeSort 
{
	public static void main(String[] args) 
	{
		Utility utility=new Utility();
		System.out.println("Enter Array size:");
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		System.out.println("Enter Strings into array:");
		String[] s=new String[size];
		for(int i=0;i<s.length;i++)
		{
			s[i]=sc.next();
		}
		System.out.println("Elements before Merge Sort:");
		for(int i=0;i<s.length;i++)
		{
			System.out.println(s[i]+" ");
		}
		
		Utility.MergeSort(s,0,s.length);
		System.out.println("Elements after Merge Sort:");
		for(int i=0;i<s.length;i++)
		{
			System.out.println(s[i]+" ");
		}
		
	}

}
