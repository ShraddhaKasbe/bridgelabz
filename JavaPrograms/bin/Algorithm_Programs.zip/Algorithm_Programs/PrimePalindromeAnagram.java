package Algorithm_Programs;

public class PrimePalindromeAnagram
{
	public static void main(String[] args) 
	{
		Utility Ut=new Utility();
		Ut.printPrimePalindrome();
		Ut.primeAnagram();
	}

}
