package Functional_Programs;

import java.util.Random;
import java.util.Scanner;

public class CouponNumbers 
{
	
	public static void DistinctCal(int num)
	{
		Random random=new Random();
		int arr[]=new int[num];
	
		for(int i=0;i<arr.length;i++)
		{
			int r=random.nextInt(num);
			arr[i]=r;
		
			for(int j=0;j<i;j++)
			{
				if(arr[i]==arr[j])
				{
					i--;
					break;
				}
			}
		}
	
		System.out.println("Unique elements in distinct coupon number are:");
		for(int i=0;i<num;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
	

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter distinct coupon number:");
		int num=sc.nextInt();
		DistinctCal(num);
			
	}
}