package Functional_Programs;

import java.util.Scanner;

public class ArrayDiemn 
{
	public static void main(String[] args)
	{
		int a[]= {10,20,20,30,10,30};
		int a1[][]=new int[3][3];
		int c=0,d=0;;
			for(int i=0;i<a.length;i++)
			{
				for(int j=i+1;j<a.length;j++)
				{
					if(a[i]==a[j] && i!=j)
					{
						if(c<3 && d<3)
						{
						a1[c][d++]=a[i];
						a1[c][d++]=i;
						a1[c][d++]=j;c++;
						
						}
							
						
					
					 }
					
				 }
			}
			
			for(c=0;c<a1.length;c++)
			{
				for(d=0;d<a1.length;d++)
				{
					System.out.print(a1[c][d]+" ");
				}
			}
			
			
			
	}
}
	
		



